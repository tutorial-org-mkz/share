#!/bin/bash
# v0.1 10/11/2021

if [[ -z $1 ]]; then
    echo "usage: $0 dbextract_file"
    echo "use config dbextract cmd to extract v5 artifacts as input here."
    exit 1
fi

echo '*************************************************'
echo '*  unpack dbextract in cloud dir and save logs  *'
echo '*************************************************'

apicm archive:unpack $1 --saveErrorLog=unpack_err.log

echo '*************************************************'
echo '*  generate artifact stats in topology dir      *'
echo '*************************************************'

apicm archive:automation cloud/provider-orgs/ --summary

echo '*************************************************'
echo '*  zip topology and logs dirs in assessment.tgz *'
echo '*************************************************'

tar -cvzf assessment.tgz topology logs

echo '*************************************************'
echo '*  Please send assessment.tgz for analysis      *'
echo '*************************************************'



