# Migration Assessment
## Important references:
* Migration Documentation: https://www.ibm.com/docs/en/api-connect/10.0.x?topic=connect-migrating-version-5-deployment
* Migration and Upgrade Central: https://www.ibm.com/support/pages/api-connect-upgrade-central-v5-v10
* Migration Overview Presentation - [Provides a high-level summary of the process as part of your planning.](https://ibm.biz/apic-v5tov10overview)
* The v5 to v10 Migration Runbook - https://ibm.biz/amu10oh-rb

## Collect Assessment Info

Exporting v5 artifacts is the first step for migration and assessments.

### Export v5 Artifacts for Migration
Prerequisites:
* v5 has to be 5.0.8.7 or newer.

Login v5 cloud manager cmd line console:
```
ssh admin@your-v5-mgmt.cloud
```

Export artifacts from v5:
https://www.ibm.com/docs/en/api-connect/5.0.x?topic=interface-configuration-commands

```
config dbextract sftp <destination_host_name> user <username> file [<path>/]<my-v5-dbextract.tgz>
```
`my-v5-dbextract.tgz` will be the input to the APIc Migration Utility (AMU). It is the basis for the assessments.

### Generate and Collect Assessment Data

If the dbextract file cannot be shared due to GDPR or other restrictions, customers can run the `assess-v5-dbextract.sh` script to generate and collect assessment data.

```
assess-v5-dbextract.sh  my-v5-dbextract.tgz
```
This will create `assessment.tgz` at the end which contains the artifacts stats and AMU logs for further assessments.


### Appendix: v5 Artifact Stats Samples

summary.json
```
v5 unpacked Artifacts Count:
{
 "ProviderOrgs": 1,
 "Catalogs": 2,
 "Published_Apis": 4,
 "Published_Products": 6,
 "Draft_Apis": 4,
 "Draft_Products": 5,
 "Spaces": 0,
 "ConsumerOrgs": 3,
 "Apps": 6,
 "Subscriptions": 5
}
```
topology.json
```
[
 {
  "name": "middleearth",
  "draft_products": 5,
  "draft_apis": 4,
  "catalog_count": 2,
  "catalogs": [
   {
    "name": "dev",
    "api": 1,
    "products": 1,
    "corg_count": 1,
    "app_count": 2,
    "subscription_count": 1
   },
   {
    "name": "sandbox",
    "api": 3,
    "products": 5,
    "corg_count": 2,
    "app_count": 4,
    "subscription_count": 4
   }
  ]
 }
]
```