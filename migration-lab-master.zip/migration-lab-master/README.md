# v5 to v10 Migration Lab
# Table of Contents
1. [Introduction](#introduction)
2. [Lab1: Explore and Export v5 Artifacts](#lab1-explore-and-export-v5-artifacts)
3. [Lab2: Migrate to v10 v5c Gateway](#lab2-migrate-to-v10-v5c-gateway)
4. [Lab3: Migrate to v10 API Gateway](#lab3-migrate-to-v10-api-gateway)
## Introduction

Lab instance URL: https://ilo.soleil.ihost.com/events/ccele/07212021ccele3753
*  enter your email address used for registration.

Lab Guide and Materials: https://github.ibm.com/mkz/migration-lab/.

Important references:
* Migration Documentation: https://www.ibm.com/docs/en/api-connect/10.0.x?topic=connect-migrating-version-5-deployment
* Migration and Upgrade Central: https://www.ibm.com/support/pages/api-connect-upgrade-central-v5-v10
* Migration Runbook: [v5 to v10 Migration Runbook](docs/v5_to_v10_MigrationRunBook.pdf)
* Migration Preparation: [Decision Tree](docs/API%20Connect%20Migration%20Questionnaire.pdf)

![migration steps](resources/migration-steps.jpg)

## Lab1: Explore and Export v5 Artifacts

Since we have only one v5 instance and there is only one actionable item in this lab, I am going to do a demo showing you the sample artifacts in v5 that we are going to migrate and exporting them out with the dbextract cmd.

### 1.1 Explore v5 artifacts to be migrated
-- showing v5 artifacts in v5 cloud and api manager.

The following credentials are needed for testing.
#### Sandbox Catalog Apps
```
`test`  app credentials: 
* client_id: 8939fc3c-3caf-42a3-8c33-00d91fb2b67b
* client_secret: qF2rA0kD2fI0lB3sC8lG1yS4tK3oL3tC4pK4fW6bW0fA4wV6kW

`test2` app credentials: 
* client_id: f3b15861-8f84-49bb-a455-da356037a405
* client_secret: Y8wR2lH5jX5aS4cU2fO2cR3nL3lL2mT4qC7mK5jO5lR4nO8pL6
```
#### Dev Catalog Apps
```
`dev-app1` app credentials: 
* Client ID: 9c1e787d-a9b5-4b86-b908-2668116bd8e3
* Client secret: oF2tB2pF5lM6tL1oL0aW8yK5xA5kX7mU6xO5tC6bW5rK0yK7fK
```

### 1.2 Export v5 Artifacts for Migration
Prerequisites:
* v5 has to be 5.0.8.7 or newer.

Login v5 cloud manager cmd line console:
```
ssh admin@v5-mgmt.apicww.cloud
```

Export artifacts from v5:
https://www.ibm.com/docs/en/api-connect/5.0.x?topic=interface-configuration-commands

```
config dbextract sftp jump.apicww.cloud user kai file migration-lab/lab_materials/dbextract-migration-lab.tgz
```
`dbextract-migration-lab.tgz` will be the input to the APIc Migration Utility (AMU). 

## Lab2: Migrate to v10 v5c Gateway

In this lab, we will unpack and push artifacts to v10 `v5c` gateway.
### 2.1 Set up Migration Env and Tools

Download the tools and v5 dbextract file:
1. Open a browser and enter URL - https://github.ibm.com/mkz/migration-lab/archive/master.zip 
2. Save `migration-lab-master.zip` file to the Downloads folder. The zip file contains all tools and the v5 dbextract file. (Basically, this clones down entire github repos https://github.ibm.com/mkz/migration-lab)
3. Open a `Terminal`. Unzip the downloaded file.
```
$ unzip ~/Downloads/migration-lab-master.zip
$ cd migration-lab-master
$ ll
```
Now you see `docs`, `tools` and `lab_materials` in the `migration-lab-master` folder which is our working directory.
```
docs:
   * v5_to_v10_MigrationRunBook.pdf
   * API Connect Migration Questionnaire.pdf
tools:
   * `apicm` - the AMU tool which we will use extensively for the migration.
   * `apic` - the apic toolkit (some scripts depends on it).
   * other optional helper utilities (mapping automation and reporting tool)
lab_materials:
   * v5 dbextract tar file
   * gateway mapping templates
```
Set up the lab env. Type in the commands below after the prompt `$`.:
```
$ export PATH="~/migration-lab-master/tools:$PATH"

$ apicm version
Do you accept license? [Y/N] Y
INFO[2021-07-16T11:53:36-05:00] APIConnect migration toolkit 8f2014f479ac375739e6b0216893c7c1071c9337 (Built 2021-06-24T19:13:52Z)
INFO[2021-07-16T11:53:36-05:00] APIConnect v10.0.3.0-R0

$ apic version 
Do you accept license? [Y/N] Y

$ apicm --help
API Connect Migration Utility (AMU)
Usage:
        apicm [command]

Available Commands:
  archive:apistatus     Generate stats about API use
  archive:automation    Generate summary of the data
  archive:gwstats       Generate stats about gatewayscript cmd use
  archive:port-to-apigw Port artifacts to apigw
  archive:push          Push unpacked content to APIConnect server
  archive:unpack        Unpack a V5 management/portal archive
  help                  Help about any command
  login                 Log in to IBM API Connect
  sluggify              Sluggify a name or version string
  version               APIConnect migration toolkit version

Flags:
      --accept-license   Accept the license for API Connect
  -h, --help             Help for apicm

Use "apicm [command] --help" for more information about a command.

```

### 2.2 Unpack and Convert v5 Artifacts 

This step will unpack v5 artifacts and convert them into v10 structure.
Pay attentions to the errors and warnings if any. At the end, the artifact summary is shown.
```
$ apicm archive:unpack lab_materials/dbextract-migration-lab.tgz --saveErrorLog="unpack_err.log"
...
{
 "ProviderOrgs": 1,
 "Catalogs": 2,
 "Published_Apis": 4,
 "Published_Products": 6,
 "Draft_Apis": 4,
 "Draft_Products": 5,
 "Spaces": 0,
 "ConsumerOrgs": 3,
 "Apps": 6,
 "Subscriptions": 5
}

```

Check logs for errs and warnings - Make sure it is err free. Otherwise fix the errs before moving to next step:
```
$ more logs/unpack_err.log
WARN[2021-07-16T02:51:24-05:00] APIConnect migration toolkit 079d36d143999afee8ec8de52d74c759301b0079 (Built 2021-07-15T22:18:24Z)
WARN[2021-07-16T02:51:24-05:00] APIConnect v10.0.3.0-R0

```

Examine the unpacked artifacts inventory. `apicm archive:automation` will generate artifacts summary and topology details.

```
$ apicm archive:automation cloud/provider-orgs/ --summary

$ ll topology/ -t
-rw-rw-r--  1 supportuser supportuser  222 Jul 16 12:40 summary.json
-rw-rw-r--  1 supportuser supportuser  385 Jul 16 12:40 topology-2021-07-16T12:40:39-05:00.json

$ more topology/topology-2021-07-16T12:40:39-05:00.json
[
 {
  "name": "middleearth",
  "draft_products": 5,
  "draft_apis": 4,
  "catalog_count": 2,
  "catalogs": [
   {
    "name": "dev",
    "api": 1,
    "products": 1,
    "corg_count": 1,
    "app_count": 2,
    "subscription_count": 1
   },
   {
    "name": "sandbox",
    "api": 3,
    "products": 5,
    "corg_count": 2,
    "app_count": 4,
    "subscription_count": 4
   }
  ]
 }
]
```

Examine the reformated artifacts in v10 structure:
* all artifacts are put in `cloud` directory. 
* cloud manager artifacts are in cloud/admin-org
* provider org artifacts are in cloud/provider-orgs
```
$ ls -l cloud
drwxr-x--- 10 supportuser supportuser 4096 Jul 16 02:51 admin-org
drwxr-x---  3 supportuser supportuser 4096 Jul 16 02:51 integrations
drwxr-x---  7 supportuser supportuser 4096 Jul 16 02:51 permissions
drwxr-x---  3 supportuser supportuser 4096 Jul 16 02:51 provider-orgs
```

### 2.3 Editing and Mapping v5 artifacts

You can fix, edit any artifacts before pushing to v10 instance. Mapping is a way to resolve any disparity between v5 and v10. Normally you need to map v5 gateways to v10 gateways and other resources needed. For details, please refer to 4.5 section in the [v5 to v10 Migration Runbook](docs/v5_to_v10_MigrationRunBook.pdf)

#### 2.3.1 Map v5 gateway to v10 v5c gateway name

To find out the name of the target v10 gateway name - 
1. login cloud manager:
   * https://cloud.mgmt.dev.apic.ibmlab.test/admin (or click the `cloud manager` on the FF bookmark bar)
   * userid/pwd: admin/api#1234
2. Topology > DataPower gateway service (v5 compatible type)
3. Topology > DataPower API gateway service (native API gateway type)

Examine the mapping file `mapping-v5cgw.yml` make sure it mapped to the right v10 gateway. In this case, the mapping file should look like - 
```
$ cat lab_materials/mapping-v5cgw.yml
gateway-service:
  name: datapower-gateway-service
```

Copy the gw mapping file to all gateway directories - 
```
$ cp lab_materials/mapping-v5cgw.yml cloud/admin-org/availability-zones/availability-zone-default/gateway-services/gateway-2536/mapping.yml

$ ll cloud/admin-org/availability-zones/availability-zone-default/gateway-services/gateway-2536
-rw-rw---- 1 supportuser supportuser  382 Jul 15 22:18 gateway-service.yml
-rw-rw-r-- 1 supportuser supportuser   51 Jul 15 23:00 mapping.yml
```

#### 2.3.2 Map v5 LDAP UR to v10 gateway LDAP UR
To find out the name of the target v10 gateway name - 
1. login cloud manager 
2. Resources > User Registries > IBM Lab LDAP > Name

Examine the mapping file `mapping-ldap.yml` make sure it mapped to the right v10 LDAP UR. In this case, the mapping file should look like - 
```
$ cat lab_materials/mapping-ldap.yml
user-registry:
  name: ibm-lab-ldap
```

Copy the LDAP mapping file to the LDAP UR directory - 
```
$ cp lab_materials/mapping-ldap.yml cloud/admin-org/user-registries/austin-lab-ldap/mapping.yml

$ ll cloud/admin-org/user-registries/austin-lab-ldap
-rw-rw---- 1 supportuser supportuser  382 Jul 15 22:18 user-registry.yml
-rw-rw-r-- 1 supportuser supportuser   51 Jul 15 23:00 mapping.yml
```

### 2.4 Push Admin_org Artifacts

Now you are ready to push the cloud artifacts to v10. 
* This needs to be done before pushing provider orgs.
* This needs to be done only ONCE for all provider orgs.
* Log in cloud manager first. Then push `cloud/admin-org/`
```
$ apicm login -s cloud.mgmt.dev.apic.ibmlab.test -u admin -p api#1234 -r admin/default-idp-1

$ apicm archive:push cloud.mgmt.dev.apic.ibmlab.test cloud/admin-org/ --saveErrorLog=admin_push_err.log
...
ERRO[...] Unable to create member boromir
ERRO[...] boromir: The user 'boromir' must belong to a user registry configured in the cloud settings.
...
```
Health Checking: 
* Fixing all errs and warning seen in `admin_push_err.log` 
  * The log will show the error msgs highlighted above. 
  * Will have to fix them
* Check and verify in v10 Cloud Manager.
  * Cloud Manager > Members shows that `boromir` is not created either.

The reason the member creation failed is because the LDAP UR is not configured for cloud manager.
* Log in cloud manager, go to Settings > User Registries > Cloud Manager > Edit
* Clicking on Edit, add / check `IBM Lab LDAP` and Save.

Now that the LDAP UR is configured, go back to rerun the push cmd again.
```
$ apicm archive:push cloud.mgmt.dev.apic.ibmlab.test cloud/admin-org/ --saveErrorLog=admin_push_err.log
...
```
This time, the log should be error free. And in v10 cloud manager, you should see all v5 admin artifacts are created there.

### 2.5 Push Provider-orgs Artifacts
Now you are ready to push artifacts in the provider orgs to v10.

Prerequisites:
* Make sure target provider org `MiddleEarth` is created on v10.
  * login cloud manager:
    * https://cloud.mgmt.dev.apic.ibmlab.test/admin (or click the `cloud manager` on the FF bookmark bar)
    * userid/pwd: admin/api#1234
    * Provider Organizations > MiddleEarth
  * login api manager with IBM LDAP UR:
    * https://apim.mgmt.dev.apic.ibmlab.test/manager (or click the `API manager` on the FF bookmark bar)
    * userid/pwd: boromir/api#1234
    * Make sure you are able to login into MiddleEarth pOrg.
* Make sure you have pushed admin-org already

```
$ apicm login -s apim.mgmt.dev.apic.ibmlab.test -u boromir -p api#1234 -r provider/ibm-lab-ldap

$ apicm archive:push apim.mgmt.dev.apic.ibmlab.test cloud/provider-orgs/middleearth --saveErrorLog=porg_push_v5c_err.log

```

Health Checking: 
* Fixing all errs and warning seen in `porg_push_v5c_err.log` 
* Check and verify in v10 

```
$ get_stats_4_all.sh cloud cloud.mgmt.dev.apic.ibmlab.test admin api#1234 admin/default-idp-1 apim.mgmt.dev.apic.ibmlab.test boromir api#1234 provider/ibm-lab-ldap

$ more artifacts_stats.txt
***************************************************************************
Artifacts in pOrg: middleearth
***************************************************************************
num of draft products: 5
num of empty draft prods (e.g. contains only oauth APIs): 1
num of net draft products:  4 : 4
num of draft APIs: 4 : 4
num of oauth-providers:  1 : 1
num of user-registries:  3 : 5
num of members:  1 : 1

===============================================================
Artifacts in catalog: dev
===============================================================
num of products:  1
num of empty products (e.g. contains only oauth APIs): 0
num of net products:  1 : 1
num of APIs:  1 : 1
num of consumer orgs: 1 : 1
num of applications: 2 : 2
num of subscriptions: 1 : 1
num of configured-tls-client-profiles:  1 : 1
num of configured-catalog-user-registries:  1 : 2
num of members:  1 : 1

===============================================================
Artifacts in catalog: sandbox
===============================================================
num of products:  5
num of empty products (e.g. contains only oauth APIs): 1
num of net products:  4 : 4
num of APIs:  3 : 3
num of consumer orgs: 2 : 3
num of applications: 4 : 5
num of subscriptions: 4 : 3
num of configured-oauth-providers:  1 : 1
num of configured-tls-client-profiles:  1 : 2
num of configured-catalog-user-registries:  2 : 2
num of members:  1 : 1
```

### 2.6 Test v10 (v5c gateway) vs v5 API

The same credentials migrated from v5 should work on the APIs migrated to v10.
* v5 end point: `gateway.v50811.apps.ova.tivlab.austin.ibm.com:9392`
* v10 v5c gw end point: `api-v5.gw.dev.apic.ibmlab.test`

Test `echo` API:
* v5
```
$ curl -k 'https://gateway.v50811.apps.ova.tivlab.austin.ibm.com:9392/middleearth/sb/echo/' -H 'x-ibm-client-id: f3b15861-8f84-49bb-a455-da356037a405'
```
* v10 (v5c gw)
```
$ curl -k 'https://api-v5.gw.dev.apic.ibmlab.test/middleearth/sandbox/echo/' -H 'x-ibm-client-id: f3b15861-8f84-49bb-a455-da356037a405'

```
Test `Pokemon` API
* v5
```
curl -k 'https://gateway.v50811.apps.ova.tivlab.austin.ibm.com:9392/middleearth/sb/poke/pokemons/45?client_id=f3b15861-8f84-49bb-a455-da356037a405'

```
* v10 (v5c gw)
```
curl -k 'https://api-v5.gw.dev.apic.ibmlab.test/middleearth/sandbox/poke/pokemons/45?client_id=f3b15861-8f84-49bb-a455-da356037a405'

```
Test `Loopback` API with OAuth:
* v5
```
curl -k --location --request POST 'https://gateway.v50811.apps.ova.tivlab.austin.ibm.com:9392/middleearth/sb/test/oauth2/token' \
--header 'Content-Type: application/x-www-form-urlencoded' \
--data-urlencode 'grant_type=client_credentials' \
--data-urlencode 'scope=scope1' \
--data-urlencode 'client_id=8939fc3c-3caf-42a3-8c33-00d91fb2b67b' \
--data-urlencode 'client_secret=qF2rA0kD2fI0lB3sC8lG1yS4tK3oL3tC4pK4fW6bW0fA4wV6kW'
{
    "token_type": "Bearer",
    "access_token": "***",
    "expires_in": 3600,
    "consented_on": 1626470536,
    "scope": "scope1"
}

curl -k --location --request GET 'https://gateway.v50811.apps.ova.tivlab.austin.ibm.com:9392/middleearth/sb/loopback' \
--header 'x-ibm-client-id: 8939fc3c-3caf-42a3-8c33-00d91fb2b67b' \
--header 'Authorization: Bearer ***'
{"test":"loopback"}
```
* v10 v5c gw
```
curl -k --location --request POST 'https://api-v5.gw.dev.apic.ibmlab.test/middleearth/sandbox/test/oauth2/token' \
--header 'Content-Type: application/x-www-form-urlencoded' \
--data-urlencode 'grant_type=client_credentials' \
--data-urlencode 'scope=scope1' \
--data-urlencode 'client_id=8939fc3c-3caf-42a3-8c33-00d91fb2b67b' \
--data-urlencode 'client_secret=qF2rA0kD2fI0lB3sC8lG1yS4tK3oL3tC4pK4fW6bW0fA4wV6kW'
{
    "token_type": "Bearer",
    "access_token": "***",
    "expires_in": 3600,
    "consented_on": 1626470929,
    "scope": "scope1"
}

curl -k --location --request GET 'https://api-v5.gw.dev.apic.ibmlab.test/middleearth/sandbox/loopback' \
--header 'x-ibm-client-id: 8939fc3c-3caf-42a3-8c33-00d91fb2b67b' \
--header 'Authorization: Bearer ***'
{"test":"loopback"}
```

## Lab3: Migrate to v10 API Gateway

In this lab, we will unpack and push artifacts to v10 `api` gateway.
### 3.1 Set up Migration Env and Tools
Same as 2.1 if having not done it yet.

### 3.2 Unpack and Convert v5 Artifacts 
Same as 2.2 if having not done it yet.

### 3.3 Editing and Mapping
You can fix, edit any artifacts before pushing to v10 instance. Mapping is a way to resolve any disparity between v5 and v10. Normally you need to map v5 gateways to v10 gateways and other resources needed. For details, please refer to 4.5 section in the [v5 to v10 Migration Runbook](docs/v5_to_v10_MigrationRunBook.pdf)

#### 3.3.1 Map v5 gateway to v10 api gateway

To find out the name of the target v10 gateway name - 
1. login cloud manager
   * https://cloud.mgmt.dev.apic.ibmlab.test/admin (or click the `cloud manager` on the FF bookmark bar)
   * userid/pwd: admin/api#1234
2. [v5c gateway] Topology > DataPower api gateway service (v5 compatible type)
3. [API Gateway] Topology > DataPower API gateway service (native API gateway type)

Examine the mapping file `mapping-apigw.yml` make sure it mapped to the right v10 gateway. In this case, the mapping file should look like - 
```
$ cat lab_materials/mapping-apigw.yml
gateway-service:
  name: datapower-api-gateway-service
  gateway-type: datapower-api-gateway
```

Copy the gw mapping file to all gateway directories (this apigw mapping file will overwrite the v5c one) - 
```
$ cp lab_materials/mapping-apigw.yml cloud/admin-org/availability-zones/availability-zone-default/gateway-services/gateway-2536/mapping.yml

$ ll cloud/admin-org/availability-zones/availability-zone-default/gateway-services/gateway-2536
-rw-rw---- 1 supportuser supportuser  382 Jul 15 22:18 gateway-service.yml
-rw-rw-r-- 1 supportuser supportuser   51 Jul 15 23:00 mapping.yml
```
#### 3.3.2 Map v5 LDAP UR to v10 gateway LDAP UR
This is the same as 2.3.2

### 3.4 Create apigw artifacts with AMU port-to-apigw option

This step will create apigw artifacts from unpacked and mapped artifacts. For details, please refer to 4.6 section in the [v5 to v10 Migration Runbook](docs/v5_to_v10_MigrationRunBook.pdf)

Prerequisites:
1. unpack 
2. mapping (at least gateway mapping)
3. This AMU option requires Node (> v10.16.0)

Before proceeding, please backup the v5c artifacts first and install nodejs.
```
$ cp -r cloud cloud.v5c

$ sudo apt install nodejs

$ node -v
10.19.0

$ apicm archive:port-to-apigw cloud --saveErrorLog="port-to-apigw-err.log"
```
Notes: Be sure to run against the “cloud” directory, and not subfolders, otherwise this migration step might fail. 

Check logs for errs and warnings - make sure this step is error free. 
```
$ cat logs/port-to-apigw-err.log
...
WARNING[] GWS04 Found `gatewayscript` policy. Porting might be required...
...
```
You might see warnings like above. In some cases, gatewayscripts need to be manually examined. But in this case, we are fine. If there are no other warnings or errors, move to next step.

### 3.5 Push Admin_org Artifacts

We need to push admin_org (repush in case you have done this in 2.4). It will push the additional api gateway-extension to v10 apigw.

```
apicm archive:push cloud.mgmt.dev.apic.ibmlab.test cloud/admin-org/ --saveErrorLog=admin_push_apigw_err.log
...
INFO[] Pushed gateway-extension ... to the API manager from datapower-api-gateway-service
...
```

Check the err log file `logs/admin_push_apigw_err.log` - make sure it is err free.

### 3.6 Push Provider-orgs Artifacts

Prerequisites:
* Make sure target provider org `MiddleEarth` is created on v10.
  * login cloud manager:
    * https://cloud.mgmt.dev.apic.ibmlab.test/admin (or click the `cloud manager` on the FF bookmark bar)
    * userid/pwd: admin/api#1234
    * Provider Organizations > MiddleEarth
  * login api manager with IBM LDAP UR:
    * https://apim.mgmt.dev.apic.ibmlab.test/manager (or click the `API manager` on the FF bookmark bar)
    * userid/pwd: boromir/api#1234
    * Make sure you are able to login into MiddleEarth pOrg.
* Make sure you have pushed admin-org already

Now ready for pushing the porgs to v10 apigw. Make sure `--apigw-only` is specified.

```
$ apicm login -s apim.mgmt.dev.apic.ibmlab.test -u boromir -p api#1234 -r provider/ibm-lab-ldap

$ apicm archive:push apim.mgmt.dev.apic.ibmlab.test cloud/provider-orgs/middleearth --apigw-only --saveErrorLog=porg_push_apigw_err.log 

```

Health Checking: 
* Fixing all errs and warning seen in `porg_push_apigw_err.log` 
* Check and verify in v10 

### 3.7 Test v10 (api gateway) vs v5 API

The same credentials migrated from v5 should work on the APIs migrated to v10.
* v5 end point: `gateway.v50811.apps.ova.tivlab.austin.ibm.com:9392`
* v10 api gw end point: `api.gw.dev.apic.ibmlab.test`

Test `echo` API:
* v5
```
$ curl -k 'https://gateway.v50811.apps.ova.tivlab.austin.ibm.com:9392/middleearth/sb/echo/' -H 'x-ibm-client-id: f3b15861-8f84-49bb-a455-da356037a405'
```
* v10 (api gw)
```
$ curl -k 'https://api.gw.dev.apic.ibmlab.test/middleearth/sandbox/echo/' -H 'x-ibm-client-id: f3b15861-8f84-49bb-a455-da356037a405'

```

Test `Pokemon` API
* v5
```
curl -k 'https://gateway.v50811.apps.ova.tivlab.austin.ibm.com:9392/middleearth/sb/poke/pokemons/45?client_id=f3b15861-8f84-49bb-a455-da356037a405'

```
* v10 (api gw)
```
curl -k 'https://api.gw.dev.apic.ibmlab.test/middleearth/sandbox/poke/pokemons/45?client_id=f3b15861-8f84-49bb-a455-da356037a405'

```

Test `Loopback` API with OAuth:
* v5
```
curl -k --location --request POST 'https://gateway.v50811.apps.ova.tivlab.austin.ibm.com:9392/middleearth/sb/test/oauth2/token' \
--header 'Content-Type: application/x-www-form-urlencoded' \
--data-urlencode 'grant_type=client_credentials' \
--data-urlencode 'scope=scope1' \
--data-urlencode 'client_id=8939fc3c-3caf-42a3-8c33-00d91fb2b67b' \
--data-urlencode 'client_secret=qF2rA0kD2fI0lB3sC8lG1yS4tK3oL3tC4pK4fW6bW0fA4wV6kW'
{
    "token_type": "Bearer",
    "access_token": "***",
    "expires_in": 3600,
    "consented_on": 1626470536,
    "scope": "scope1"
}

curl -k --location --request GET 'https://gateway.v50811.apps.ova.tivlab.austin.ibm.com:9392/middleearth/sb/loopback' \
--header 'x-ibm-client-id: 8939fc3c-3caf-42a3-8c33-00d91fb2b67b' \
--header 'Authorization: Bearer ***'
{"test":"loopback"}
```
* v10 (api gw)
```
curl -k --location --request POST 'https://api.gw.dev.apic.ibmlab.test/middleearth/sandbox/test/oauth2/token' \
--header 'Content-Type: application/x-www-form-urlencoded' \
--data-urlencode 'grant_type=client_credentials' \
--data-urlencode 'scope=scope1' \
--data-urlencode 'client_id=8939fc3c-3caf-42a3-8c33-00d91fb2b67b' \
--data-urlencode 'client_secret=qF2rA0kD2fI0lB3sC8lG1yS4tK3oL3tC4pK4fW6bW0fA4wV6kW'
{
    "token_type": "Bearer",
    "access_token": "***",
    "expires_in": 3600,
    "consented_on": 1626470929,
    "scope": "scope1"
}

curl -k --location --request GET 'https://api.gw.dev.apic.ibmlab.test/middleearth/sandbox/loopback' \
--header 'x-ibm-client-id: 8939fc3c-3caf-42a3-8c33-00d91fb2b67b' \
--header 'Authorization: Bearer ***'
{"test":"loopback"}
```

## References:

https://github.ibm.com/mkz/migration-lab

