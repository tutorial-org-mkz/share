## Hardware Requirements

VM Name | Num | CPUs | RAM | Disk | OS
|--|--|--|--|--|--|
v5 API mgr | 1 | 4 | 16GB | 400GB | RHEL 8 CLI
v5 GW | 1 | 4 | 16GB | 100 GB | RHEL 8 CLI
v10 API mgr | 16 | 4 | 16GB | 350GB | RHEL 8 CLI
v5c & API Gateways | 16 | 8 | 16GB | 100 GB | RHEL 8 CLI
AMU server | 16 | 4 | 8GB | 100 GB | RHEL 8 Gnome

## Here are the references - 
* https://www.ibm.com/docs/en/api-connect/10.0.x?topic=connect-requirements-initial-deployment-vmware
* https://www.ibm.com/docs/en/api-connect/10.0.x?topic=dr-api-connect-version-10-software-product-compatibility-requirements#overview_apimgmt_requirements
