#!/bin/bash
# v5.0
# 7/19/2020
# mkz@us.ibm.com
#
# usage: get_stats_4_admin_org.sh <ADMIN_ORG_dir> [ <apim_server> <ADMIN_ORG_user> <ADMIN_ORG_pwd> <ADMIN_ORG_realm> <toplogy_file> ]
#   <ADMIN_ORG_dir>: admin org dir in the unpacked cloud folder. e.g. cloud/admin-orgs
#
#   The rest arugments are optional:
#   <apim_server>: api manager
#   <ADMIN_ORG_user>, ADMIN_ORG_pwd: ADMIN_ORG credentials
#   <topology_file>: the output file from get_topology.sh
#
#   Output: stats files are saved in <ADMIN_ORG_dir>/stats
#
# Prerequsites:
# 1. <topology_file>: the output file from get_topology.sh
# 2. jq
# 3. get_stats_from_server.sh
# 4. apic

#normalize to remove the last /
ADMIN_ORG=$(
    cd "$1"
    pwd
)

SERVER=$2

USERNAME=$3
PASSWORD=$4
REALM=$5
#provider/default-idp-2

TOPOLOGY_FILE_IN=$6
#TOPOLOGY_FILE=topology_stats.json
TOPOLOGY_FILE=$(echo $(pwd)/$TOPOLOGY_FILE_IN)
#echo TOPOLOGY_FILE=$TOPOLOGY_FILE

# ORG=$(echo $ADMIN_ORG | sed -e "s|.*/||")
ORG=admin

cd $ADMIN_ORG

# STATSDIR=$(echo $(pwd)/stats)
# if [[ -d $STATSDIR ]]; then
#     rm -r $STATSDIR
# fi
# mkdir $STATSDIR

function find_artifacts() {
    #echo -- $1 $2 $3
    #if [[ -d $1 ]]; then
    artifact_type=$(echo $1 | sed -e "s|.*/||")

    if [[ ! -d $1 ]]; then
        local_num=0
    else
        local_num=$(ls $1 | wc -l)
    fi

    if [ -z "$SERVER" ]; then
        echo "num of $artifact_type: " $local_num
    else
        echo "num of $artifact_type: " $local_num : $(get_stats_from_server.sh $SERVER $ORG $USERNAME $PASSWORD $REALM $1 $2 $3)
    fi
    #fi
}

echo
echo "***************************************************************************"
echo Artifacts in ADMIN_ORG: $ORG
echo "***************************************************************************"

#echo "num of OAuth Providers: " `ls oauth-providers | wc -l`
find_artifacts "oauth-providers" "list"

#echo "num of tls-client-profiles: " `ls tls-client-profiles | wc -l`
find_artifacts "tls-client-profiles" "list-all"

#echo "num of user-registries: " `ls user-registries | wc -l`
find_artifacts "user-registries" "list"

find_artifacts "members" "list" "org"
