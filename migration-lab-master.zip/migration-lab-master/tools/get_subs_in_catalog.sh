#!/bin/bash
# v1.0
# get stats
# mkz@us.ibm.com

SERVER=$1
ORG=$2
CATALOG=$3

USERNAME=$4
PASSWORD=$5
#provide the user registry for the porg
REGISTRY=$6
#REGISTRY=provider/playground-ldap

CLIENT_ID=599b7aef-8841-4ee2-88a0-84d49c4d6ff2
CLIENT_SECRET=0ea28423-e73b-47d4-b40e-ddb45c48bb0c

# Get bearer token
# echo "Getting token"
TOKEN_RESPONSE=$(curl -k -s -X POST -d '{"username": "'$USERNAME'", "password": "'$PASSWORD'", "realm": "'$REGISTRY'", "client_id": "'$CLIENT_ID'", "client_secret": "'$CLIENT_SECRET'", "grant_type": "password"}' -H 'Content-Type: application/json' -H 'Accept: application/json' https://$SERVER/api/token)
#echo $TOKEN_RESPONSE

TOKEN=$(grep access_token <<<"$TOKEN_RESPONSE" | sed -e s/.*:.// | sed -e s/[\"\|\,]//g)
#echo "Token =" $TOKEN

# echo "--- create draft Products"
# curl -k --request POST \
#     -H "Accept: application/json" \
#     -H "content-type: application/yaml" \
#     -H "Authorization: bearer $TOKEN" \
#     -d @testprod2.1.yaml \
#     https://$SERVER/api/orgs/$ORG/drafts/draft-products


# echo "--- create draft Products"
# curl -k --request POST \
#     -H "Accept: application/json" \
#     -H "content-type: application/json" \
#     -H "Authorization: bearer $TOKEN" \
#     -d @testprod2.json \
#     https://$SERVER/api/orgs/$ORG/drafts/draft-products

# echo "--- Getting draft Products"
# curl -k --request GET \
#  -H "Accept: application/json" \
#  -H "Authorization: bearer $TOKEN" \
# https://$SERVER/api/orgs/$ORG/drafts/draft-products
# https://$SERVER/api/orgs/$ORG/drafts/draft-products/fee31b35-70b5-4eed-91b0-e827273d08ab/document
# https://$SERVER/api/orgs/$ORG/drafts/draft-products?fields="name,created_at,updated_at,url" > draft_prods_in_$ORG.json

# echo "--- update draft Products"
# curl -k --request PATCH \
#  -H "Accept: application/json" \
#  -H "content-type: application/json" \
#  -H "Authorization: bearer $TOKEN" \
#  -d @testprod3.json \
# https://$SERVER/api/orgs/$ORG/drafts/draft-products/kaitestprod2/1.0.0

# echo "--- delete draft API"
# curl -k --request DELETE \
#  -H "Accept: application/json" \
#  -H "content-type: application/json" \
#  -H "Authorization: bearer $TOKEN" \
# https://$SERVER/api/orgs/$ORG/drafts/draft-apis/echo/1.0.0

# echo "--- retire product"
# curl -k --request PATCH \
#  -H "Accept: application/json" \
#  -H "content-type: application/json" \
#  -H "Authorization: bearer $TOKEN" \
#  -d '{"state": "retired"}'  \
# https://$SERVER/api/catalogs/$ORG/$CATALOG/products/kaitestprod2/1.0.0
# #https://apim.lts.apicww.cloud/api/catalogs/kai/9bac60c7-1076-46d6-9a92-aa878d54fb50/products/866cc046-7a31-434a-9a6d-6cf94d9a80d8

# echo "--- delete product"
# curl -k --request DELETE \
#  -H "Accept: application/json" \
#  -H "content-type: application/json" \
#  -H "Authorization: bearer $TOKEN" \
# https://$SERVER/api/catalogs/$ORG/$CATALOG/products/kaitestprod2/1.0.0


curl -k --request GET \
 -H "Accept: application/json" \
 -H "Authorization: bearer $TOKEN" \
 https://$SERVER/api/catalogs/$ORG/$CATALOG/subscriptions?limit=10000&offset=0&fields=product,product_version,app,plan_title,plan,consumer_org,updated_at,id,url&expand=product,app,consumer_org

# Request URL: https://mgmt.v2018.apicww.cloud/api/catalogs/be11145a-1863-46cd-91f9-6199f07d7afb/0d87411f-ed18-4d98-a1ef-af6756c9ac1c/subscriptions?limit=1000&offset=0&fields=product,product_version,app,plan_title,plan,consumer_org,updated_at,id,url&expand=product,app,consumer_org

# Request URL: https://mgmt.v2018.apicww.cloud/api/catalogs/be11145a-1863-46cd-91f9-6199f07d7afb/0d87411f-ed18-4d98-a1ef-af6756c9ac1c/products?limit=1000&offset=0&fields=title,name,version,state,plans,updated_at,id,url&expand=plans

# Request URL: https://mgmt.v2018.apicww.cloud/api/catalogs/be11145a-1863-46cd-91f9-6199f07d7afb/0d87411f-ed18-4d98-a1ef-af6756c9ac1c/products?limit=1000&offset=0&fields=title,version,apis,plans,foundIn,state,id,url&expand=apis,plans
