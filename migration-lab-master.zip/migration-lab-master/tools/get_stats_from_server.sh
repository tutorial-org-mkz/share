#!/bin/bash
# v4.0
# 7/17/2020
# mkz@us.ibm.com
#
# get resource stats of the "markets" org
# get_stats_from_server.sh mgmt.fp12.apicww.cloud markets mkz 7iron-hide provider/default-idp-2 oauth-providers list
# get_stats_from_server.sh mgmt.fp12.apicww.cloud markets mkz 7iron-hide provider/default-idp-2 tls-client-profiles list-all
# get_stats_from_server.sh mgmt.fp12.apicww.cloud markets mkz 7iron-hide provider/default-idp-2 draft-products list-all
# get_stats_from_server.sh mgmt.fp12.apicww.cloud markets mkz 7iron-hide provider/default-idp-2 catalogs/sandbox/configured-catalog-user-registries list no-scope
# get_stats_from_server.sh mgmt.fp12.apicww.cloud markets mkz 7iron-hide provider/default-idp-2 catalogs/sandbox/configured-tls-client-profiles list-all
# get_stats_from_server.sh mgmt.fp12.apicww.cloud markets mkz 7iron-hide provider/default-idp-2 members no-action org
# get_stats_from_server.sh mgmt.fp12.apicww.cloud markets mkz 7iron-hide provider/default-idp-2 members list org
#
# get resource stats of the "admin" org
# get_stats_from_server.sh cm.fp12.apicww.cloud admin admin 8iron-hide admin/default-idp-1 tls-client-profiles list-all
# get_stats_from_server.sh cm.fp12.apicww.cloud admin admin 8iron-hide admin/default-idp-1 tls-client-profiles list-all

SERVER=$1
ORG=$2
USERNAME=$3
PASSWORD=$4
REALM=$5
TARGET=$6
ACTION=$7
SCOPE=$8

if [ -z "$SERVER" ]; then
    echo -- server name is empty.
    exit 1

    # if server is empty, overwrite apic to escape apic calls
    # function apic() {
    #     echo
    # }
fi

# check if the access token has expired, if not reuse it
# expires_at: 1595086825
if [[ -f ~/.apiconnect/token ]]; then
    expires_at=$(cat ~/.apiconnect/token | grep -A 3 "$SERVER/api" | grep expires_at | sed "s/.*: //")
fi
# set to 0 if it is not a number
if [[ ! $expires_at =~ ^-?[0-9]+$ ]]; then
    expires_at=0
fi

current_time=$(date +%s)
if (($expires_at < $current_time)); then
    # already expired, relogin
    apic login -s $SERVER -u $USERNAME -p $PASSWORD -r $REALM
fi

#IFS='/' read -r -a array <<<$TARGET #does not work in fucntion
array=($(echo "$TARGET" | tr '/' '\n'))

if ((${#array[@]} == 1)); then
    # pOrg level: draft-products, oauth-providers etc
    # apic TARGET[:ACTION] -s SERVER -o PORG [--scope SCOPE]
    tmp=$(apic $TARGET$([[ "no-action" == $ACTION ]] && echo "" || echo :$ACTION) -s $SERVER -o $ORG $([ ! -z "$SCOPE" ] && echo --scope $SCOPE || echo "") 2>&1)

elif ((${#array[@]} == 3)); then
    if [[ -z $SCOPE ]]; then
        SCOPE=catalog
    fi
    #catalog level: catalogs/catalog_name/configured-oauth-providers
    # echo -- apic ${array[2]}:$ACTION --scope $SCOPE -s $SERVER -c ${array[1]} -o $ORG
    if [[ "no-scope" == $SCOPE ]]; then
        tmp=$(apic ${array[2]}:$ACTION -s $SERVER -c ${array[1]} -o $ORG 2>&1)
    else
        tmp=$(apic ${array[2]}:$ACTION --scope $SCOPE -s $SERVER -c ${array[1]} -o $ORG 2>&1)
    fi

elif ((${#array[@]} == 5)); then
    #space level: catalogs/catalog_name/spaces/space_name/configured-oauth-providers
    if [[ -z $SCOPE ]]; then
        SCOPE=space
    fi
    tmp=$(apic ${array[4]}:$ACTION --scope $SCOPE -s $SERVER -c ${array[1]} --space ${array[3]} -o $ORG 2>&1)

else
    echo "skip because not able to parse $TARGET"
fi

# handle Forbidden eror
if [[ "$tmp" == *"Error"* ]]; then
    echo "skip because of $tmp"
else
    num=$(echo $tmp | grep -o "http" | wc -l)
    #echo -e "\t$org\t-- num of $TARGET: $num"
    echo $num
fi
