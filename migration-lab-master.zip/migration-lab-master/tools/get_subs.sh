#!/bin/bash
# v1.0
# get stats 
# mkz@us.ibm.com

SERVER=$1
ORG=$2
CATALOG=$3

USERNAME=$4
PASSWORD=$5
#provide the user registry for the porg
#REGISTRY=playground-ldap
REGISTRY=$6

CLIENT_ID=599b7aef-8841-4ee2-88a0-84d49c4d6ff2
CLIENT_SECRET=0ea28423-e73b-47d4-b40e-ddb45c48bb0c

# Get bearer token
echo "Getting token"

TOKEN_RESPONSE=$(curl -k -s -X POST -d '{"username": "'$USERNAME'", "password": "'$PASSWORD'", "realm": "provider/'$REGISTRY'", "client_id": "'$CLIENT_ID'", "client_secret": "'$CLIENT_SECRET'", "grant_type": "password"}' -H 'Content-Type: application/json' -H 'Accept: application/json' https://$SERVER/api/token)
#echo $TOKEN_RESPONSE

TOKEN=$(grep access_token <<< "$TOKEN_RESPONSE" | sed -e s/.*:.// | sed -e s/[\"\|\,]//g)
echo "Token obtained"
#echo "Token =" $TOKEN

echo "--- Getting apps"
curl -k --request GET \
 -H "Accept: application/json" \
 -H "Authorization: bearer $TOKEN" \
 https://$SERVER/api/catalogs/$ORG/$CATALOG/apps?fields="name,created_at,updated_at,url" > apps_in_$ORG_$CATALOG.json
#"url": "https://sit.mkts.apicmgmt.citigroup.net/api/apps/94a58d33-bbcf-46dd-b0f0-10b336966c57/52042846-c38c-4177-8297-761f3cc10044/024ef2b0-18b6-400f-8baa-abb3a3f11b36/a55acbe3-eec0-41a2-847c-dfa8e2eafe18"


#get_subs_4_apps.sh $TOKEN apps_in_$ORG_$CATALOG.json
echo ====== found subs for apps in apps_in_$ORG_$CATALOG.json ======
counter=0

jq -rc '.results[]' apps_in_$ORG_$CATALOG.json | while IFS='' read item;do

    #updateat=$(echo "$item" | jq .updated_at | tr -d '"') 
    #echo - updated_at: $updateat
    #echo --- `date -d $updateat +%s`
    #convert to seconds
    #updateatsecs=$(date -d $updateat +%s)
    #echo - update at: $updateatsecs vs last check at: $LAST_CHECK_TIME_SEC
    #echo $item

    #get the details
    name=$(echo "$item" | jq .name | tr -d '"')
    echo "-- finding new subs for app: $name"

    # this url can be used to contruct the query for getting its subscriptions
    # "url": "https://sit.mkts.apicmgmt.citigroup.net/api/apps/94a58d33-bbcf-46dd-b0f0-10b336966c57/52042846-c38c-4177-8297-761f3cc10044/024ef2b0-18b6-400f-8baa-abb3a3f11b36/a55acbe3-eec0-41a2-847c-dfa8e2eafe18"
    url=$(echo "$item" | jq .url | tr -d '"')
    #echo url : $url

    # echo "--- Getting subs"
    counter=$((counter+1))
    curl -k --request GET \
        -H "Accept: application/json" \
        -H "Authorization: bearer $TOKEN" \
        $url/subscriptions?fields="name,url" > subs_in_${name}--${counter}.json

    #./find_new_items.sh subs_in_$name.json
    #echo `grep total_results subs_in_$name.json`
    #cat subs_in_$name.json 
    num1=$(jq .total_results subs_in_${name}--${counter}.json)
    echo current subs: $num1
    total=$((num1 + total))
    echo $total > total_subs.txt
done



