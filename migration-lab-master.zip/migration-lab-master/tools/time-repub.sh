# v1.0

#APIGW=$1
ENDPT=$1
CLIENT_ID_FILE=$2
PAUSE_SECS=$3

# read / initialize client ids
readarray -t clientids <$CLIENT_ID_FILE

time_elapsed=0
while true; do

    date

    # echo "------ call api newly published  ..."
    # echo
    echo "--------------------------------- "

    for clientid in "${clientids[@]}"; do

        echo "----> curl -s -k -H "x-ibm-client-id: $clientid" $ENDPT ..."
        curl -s -k -H "x-ibm-client-id: $clientid" $ENDPT

        echo
        echo "--------------------------------- "
    done

    sleep $PAUSE_SECS
    ((time_elapsed += $PAUSE_SECS))
    echo "Time spent so far: $time_elapsed"

done

