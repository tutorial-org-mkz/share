#!/bin/bash
# v5.1
# 10/7/2020
# mkz@us.ibm.com
#
# usage: get_stats_4_all.sh <cloud_dir> [ <cm_server> <admin_user> <admin_pwd> <admin_realm> <apim_server> <porg_user> <porg_pwd> <porg_realm> ]
#   cloud_dir[optional]: unpacked provider orgs dir. default to cloud.
#
#   The following arguments are optional.
#   When not present, the script generates stats for the local unpacked artifacts only.
#   When present, the script generates stats for both local unpacked artifacts and artifacts on target API manager. and list them side side.
#
#   cm_server: cloud manager
#   admin credentials: cmc admin credential
#   apim_server: API manager
#   porg credentials: porg user credential
#
# Outputs:
#   1. The detailed stats for each category and space are saved to "artifacts_stats.txt"
#   2. This also creates the lists of artifacts for each type in the <porg_dir>/stats dir for each porg.
#
# Dependencies:
#   1. jq - JSON processor. Install: sudo apt-get install jq

#normalize to remove the last /
CLOUDDIR=$1

CM_SERVER=$2
ADM_USERNAME=$3
ADM_PASSWORD=$4
ADM_REALM=$5

APIM_SERVER=$6
PORG_USERNAME=$7
PORG_PASSWORD=$8
PORG_REALM=$9

GET_STATS_4_PORG=get_stats_4_porg.sh
GET_STATS_4_ADMIN_ORG=get_stats_4_admin_org.sh
GET_TOPOLOGY=get_topology.sh

TOPOLOGY_FILE=topology_stats.json
STATS_FILE=artifacts_stats.txt

if [[ -f $STATS_FILE ]]; then
    rm $STATS_FILE
fi

if [ -z "$CLOUDDIR" ]; then
    PORGDIR=cloud/provider-orgs
else
    PORGDIR=$CLOUDDIR/provider-orgs
fi

ADMIN_ORG_DIR=$(echo $PORGDIR | sed "s|provider-orgs|admin-org|")

# add current dir to search path
export PATH=$PATH:.

porgs=($(ls $PORGDIR))
echo ===============================================================
echo admin-org and provider orgs : ${porgs[@]}
echo ===============================================================

############## get v2018 topology stats ###############
if [ ! -z "$CM_SERVER" ]; then
    $GET_TOPOLOGY $CM_SERVER $ADM_USERNAME $ADM_PASSWORD $ADM_REALM >$TOPOLOGY_FILE
fi

##########################################################
# get admin org stats
##########################################################
echo -- working on admin-org $org ...
if [ ! -z "$CM_SERVER" ]; then
    $GET_STATS_4_ADMIN_ORG $ADMIN_ORG_DIR $CM_SERVER $ADM_USERNAME $ADM_PASSWORD $ADM_REALM >>$STATS_FILE
else
    $GET_STATS_4_ADMIN_ORG $ADMIN_ORG_DIR >>$STATS_FILE
fi

##########################################################
# get pOrg stats
##########################################################
for org in "${porgs[@]}"; do
    echo -- working on pOrg $org ...
    #$GET_STATS_4_PORG $PORGDIR/${porgs[0]}
    if [ ! -z "$APIM_SERVER" ]; then
        $GET_STATS_4_PORG $PORGDIR/$org $APIM_SERVER $PORG_USERNAME $PORG_PASSWORD $PORG_REALM $TOPOLOGY_FILE >>$STATS_FILE
    else
        $GET_STATS_4_PORG $PORGDIR/$org >>$STATS_FILE
    fi
done

sed -i -e '/Logged into/d' $STATS_FILE

function sum_array() {
    #arr5=($(grep "$1" $STATS_FILE | sed -e s/"$1:"// | sed -e s/:.*//))
    grep "$1" $STATS_FILE | sed -e s/"$1:"// >statstmp.txt

    IFS=$'\n' read -d '' -r -a lines <statstmp.txt
    #echo ${#lines[*]}
    tot5=0
    tot2018=0
    for ((i = 0; i < ${#lines[@]}; i++)); do
        vals=($(echo "${lines[i]}" | tr ':' '\n'))
        # echo ${vals[*]}
        let tot5+=${vals[0]}
        if ((${#vals[*]} > 1)); then
            let tot2018+=${vals[1]}
        fi
    done

    echo "Total $1: $tot5 : $tot2018" $3

    if [[ -f statstmp.txt ]]; then
        rm statstmp.txt
    fi
}

echo ===============================================================
echo Artifacts Summary
echo ===============================================================

echo num of pOrgs: ${#porgs[@]}
echo Total num of catalogs: $(grep catalog: $STATS_FILE | wc -l)
echo Total num of space: $(grep space: $STATS_FILE | wc -l)

draft_prods="num of net draft products"
sum_array "${draft_prods}"

draft_apis="num of draft APIs"
sum_array "${draft_apis}"

prods="num of net products"
sum_array "${prods}"

apistr="num of APIs"
sum_array "${apistr}"

corgs="num of consumer orgs"
sum_array "${corgs}"

apps="num of applications"
sum_array "${apps}"

subs="num of subscriptions"
sum_array "${subs}"

oauth="num of oauth-providers"
sum_array "${oauth}" " : including the public ones inherited from cmc"

tls="num of tls-client-profiles"
sum_array "${tls}" " : including the public ones inherited from cmc"

registries="num of user-registries"
sum_array "${registries}" " : including the public ones inherited from cmc"

echo
echo "Note: The detailed stats for each catagory and space are saved to \"$STATS_FILE\""
echo
