#!/bin/bash
# version: 3.1  9/19/2020
# mkz@us.ibm.com
#
# Replace, remove or insert the name and value in given swagger files
#
# usage: cmd [-s specfic_replacement_file] [-g global_replacement_file] [-d dir]
#   - specfic_replacement_file [optional]: specify the node-value pairs to be replaced or inserted or removed
#   - global_replacement_file [optional]: specify the global replacement for a given string
#   - dir [optional]: the dir structure that are searched for the file names specified in the replacement files.
#
# You need the helper utilities:
#   1. jq - JSON processor. Install: sudo apt-get install jq
#   2. json2yaml / yaml2json:   pip3 install python-json2yaml or sudo snap install remarshal.
#      If running into the problem: "snap-confine has elevated permissions and is not confined but should be. Refusing to continue to avoid permission escalation attacks"
#      Run this cmd: "sudo systemctl enable --now apparmor.service"
#
# Input files:
#   1. specfic_replacement_file: see the Sample/specific.csv
#   2. global_replacement_file: see the Sample/global.csv

function help() {
    echo "Replace, remove or insert the name and value in given swagger files."
    echo
    echo "cmd [-s specfic_replacement_file] [-g global_replacement_file] [-d dir]"
    echo
    echo "- specfic_replacement_file [optional]: specify the node-value pairs to be replaced or inserted or removed"
    echo "- global_replacement_file [optional]: specify the global replacement for a given string"
    echo "- dir [optional]: the dir structure that are searched for the file names specified in the replacement files."
    echo
    echo "Note: It need jq and python util json2yaml to run."
    echo "In running into the problem: snap-confine has elevated permissions and is not confined but should be. Refusing to continue to avoid permission escalation attacks"
    echo "Run this cmd: sudo systemctl enable --now apparmor.service"
    exit 1
}

# Loop through arguments and process them
while (("$#")); do
    #echo - $1
    case "$1" in
    -s)
        specific_file="$2"
        shift 2
        ;;
    -g)
        global_file="$2"
        shift 2
        ;;
    -d)
        dir="$2"
        shift 2
        ;;
    *)
        OTHER_ARGUMENTS+=("$1")
        shift # Remove generic argument from processing
        ;;
    esac
done

if [ ! -z "$OTHER_ARGUMENTS" ] || [ -z "$specific_file" ] && [ -z "$global_file" ]; then
    #echo -s $specific_file -g $global_file -d $dir
    help
fi

# default to current dir
if [ -z "$dir" ]; then
    dir=.
fi

# Handle global replacement / delete first
# read the global_file in array. ignore comment lines starting with #
# arr=($(grep -v "^#" $global_file))
if [ -f "$global_file" ]; then
    grep -v "^#" $global_file >tmp_file
    IFS=$'\n' read -d '' -r -a lines <tmp_file

    echo "*****************************************************************"
    echo The following global values are replaced / deleted
    echo "*****************************************************************"
    for i in ${!lines[*]}; do
        echo ${lines[i]}
    done

    for i in "${!lines[@]}"; do
        #ops=(${i/${lines[i]}/,/ })
        IFS=',' read -r -a ops <<<"${lines[i]}"
        file=${ops[0]}
        # find all instances of the file
        api_files=($(find $dir/$(dirname $file) -name $(basename $file)))

        if [ ${#api_files[@]} -eq 0 ]; then
            echo "ERROR ==> $file is NOT found!"
            continue
        fi

        for f in "${api_files[@]}"; do
            # handle block deletion
            if [ "${ops[1]}" = "/DELETE/" ]; then
                if [[ "${ops[2]}" == *"<-->"* ]]; then
                    # case 1: delete a block between 2 line numbers (inclusive)
                    # line1|matching_substring<-->line2
                    # delete between line and line2 where line1 contains substring of ”matching_substring“
                    line1=$(echo "${ops[2]}" | sed "s/|.*//")
                    line2=$(echo "${ops[2]}" | sed "s/.*<-->//")
                    substring=$(echo "${ops[2]}" | sed "s/.*|//" | sed "s/<-->.*//")
                    line=$(sed -n "${line1}p" $f)
                    echo "---- working on $f: deleting block between line $line1 with $line2"

                    if [[ "$line" =~ .*"$substring".* ]]; then
                        echo "---- working on $f: deleted block between line $line1 with $line2 with starting line: $line"
                        sed -i "${line1},${line2}d" $f
                    else
                        echo "---- WARNING: Could not delete the block from $f starting at line $line1: $line"
                    fi
                else
                    # case 2: delete lines matching the given pattern
                    echo "---- working on $f: deleting lines matching pattern: ${ops[2]} "
                    sed -i "/${ops[2]}/d" $f
                fi
            else
                # case 3: replace
                echo ---- working on $f: replace ${ops[1]} with ${ops[2]} globally
                sed -i -e "s|${ops[1]}|${ops[2]}|g" $f
            fi
        done
    done
fi

# read the specific_file in array. ignore comment lines starting with #
if [ -f "$specific_file" ]; then
    grep -v "^#" $specific_file >tmp_file
    IFS=$'\n' read -d '' -r -a lines <tmp_file

    echo "*****************************************************************"
    echo The following speclifc values are replaced or removed or added
    echo "*****************************************************************"
    for i in ${!lines[*]}; do
        echo ${lines[i]}
    done
    echo "------------------------------------------------------"

    for i in "${!lines[@]}"; do
        #ops=(${i/${lines[i]}/,/ })
        IFS=',' read -r -a ops <<<"${lines[i]}"
        file=${ops[0]}
        # find all instances of the file
        # get relative dirname and basename from file
        api_files=($(find $dir/$(dirname $file) -name $(basename $file)))

        if [ ${#api_files[@]} -eq 0 ]; then
            echo "ERROR ==> $file is NOT found!"
            continue
        fi

        for f in "${api_files[@]}"; do

            # if ${ops[2]} is set, then to replace the value; if not set remove the node
            if [ -z "${ops[2]}" ]; then
                echo ---- working on $f: removing the node ${ops[1]}
                jq_op="jq 'del(.${ops[1]})'"
            else
                echo ---- working on $f: replacing or insert the value of ${ops[1]} with ${ops[2]}
                jq_op="jq '.${ops[1]}=${ops[2]}'"
            fi

            # redirect and catch error msgs
            tmp=$(yaml2json $f | eval $jq_op | json2yaml >tmp_yaml_file 2>&1)

            # handle snap eror
            if [[ "$tmp" == *"snap-confine"* ]]; then
                echo "Error: $tmp"
                echo "Run this cmd to fix the error: sudo systemctl enable --now apparmor.service"
            else
                mv tmp_yaml_file $f
            fi
            #yq r -j -P $f | jq '."info"."contact"."email" = "kai@ibm.com"'
        done
    done
fi

echo "------------------------------------------------------"

# cleanup
if [ -f tmp_file ]; then
    rm tmp_file
fi
