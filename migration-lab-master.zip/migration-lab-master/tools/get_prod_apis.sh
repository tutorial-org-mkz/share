#!/bin/bash
# v1.0
#
# "source get_token.sh" to get token and set up the env variables for REST calls.
# mkz@us.ibm.com

ORG=$1
CATALOG=$2

# optional
SERVER=$3
USERNAME=$4
PASSWORD=$5
#provide the user registry for the porg
REGISTRY=$6

CLIENT_ID=599b7aef-8841-4ee2-88a0-84d49c4d6ff2
CLIENT_SECRET=0ea28423-e73b-47d4-b40e-ddb45c48bb0c

# default values
if [ -z $SERVER ]; then
    SERVER=apim.mgmt.prod.markets.apps.citi.austinlab.test
fi
if [ -z $USERNAME ]; then
    USERNAME=kai
fi
if [ -z $PASSWORD ]; then
    PASSWORD=7iron-hide
fi
if [ -z $REGISTRY ]; then
    REGISTRY=provider/default-idp-2
fi

echo "-----------------------------------"
echo "Set up env ..."
echo "-----------------------------------"
echo "ORG=$ORG"
echo "CATALOG=$CATALOG"
echo "SERVER=$SERVER"
echo "USERNAME=$USERNAME"
echo "PASSWORD=$PASSWORD"
echo "REGISTRY=$REGISTRY"
echo "-----------------------------------"
# Get bearer token
echo "Getting token ... "
echo "-----------------------------------"
TOKEN_RESPONSE=$(curl -k -s -X POST -d '{"username": "'$USERNAME'", "password": "'$PASSWORD'", "realm": "'$REGISTRY'", "client_id": "'$CLIENT_ID'", "client_secret": "'$CLIENT_SECRET'", "grant_type": "password"}' -H 'Content-Type: application/json' -H 'Accept: application/json' https://$SERVER/api/token)
# echo $TOKEN_RESPONSE

TOKEN=$(grep access_token <<<"$TOKEN_RESPONSE" | sed -e s/.*:.// | sed -e s/[\"\|\,]//g)
echo "TOKEN =" $TOKEN
echo "-----------------------------------"

echo "get products from catalog $CATALOG ... save to products.json"
curl --request GET -H "Accept: application/json" -H "Authorization: bearer $TOKEN" https://$SERVER/api/catalogs/$ORG/$CATALOG/products -k >products.json 2>/dev/null

echo "get APIs from catalog $CATALOG ... save to apis.json 2"
curl --request GET -H "Accept: application/json" -H "Authorization: bearer $TOKEN" https://$SERVER/api/catalogs/$ORG/$CATALOG/apis -k >apis.json 2>/dev/null

echo "get draft products from pOrg $ORG ... save to draft-products.json"
curl --request GET -H "Accept: application/json" -H "Authorization: bearer $TOKEN" https://$SERVER/api/orgs/$ORG/drafts/draft-products -k >draft-products.json 2>/dev/null

echo "get draft APIs from pOrg $ORG ... save to draft-apis.json"
curl --request GET -H "Accept: application/json" -H "Authorization: bearer $TOKEN" https://$SERVER/api/orgs/$ORG/drafts/draft-apis -k >draft-apis.json 2>/dev/null

echo "-----------------------------------"
