#!/bin/bash
# v5.1
# 9/15/2020
# mkz@us.ibm.com
#
# usage: get_stats_4_porg.sh <pOrg_dir> [ <apim_server> <porg_user> <porg_pwd> <porg_realm> <toplogy_file> ]
#   <pOrg_dir>: provider org dir in the unpacked cloud folder. e.g. cloud/provider-orgs/myporg
#
#   The rest arugments are optional:
#   <apim_server>: api manager
#   <porg_user>, porg_pwd: porg credentials
#   <topology_file>: the output file from get_topology.sh
#
#   Output: stats files are saved in <pOrg_dir>/stats
#
# Prerequsites:
# 1. [optional] <topology_file>: the output file from get_topology.sh
# 2. [optional] jq
# 3. [optional] get_stats_from_server.sh

#normalize to remove the last /
PORG=$(
    cd "$1"
    pwd
)

SERVER=$2

USERNAME=$3
PASSWORD=$4
REALM=$5
#provider/default-idp-2

TOPOLOGY_FILE_IN=$6
#TOPOLOGY_FILE=topology_stats.json
TOPOLOGY_FILE=$(echo $(pwd)/$TOPOLOGY_FILE_IN)
#echo TOPOLOGY_FILE=$TOPOLOGY_FILE

# here has an issue -- porg cannot end with "/"
ORG=$(echo $PORG | sed -e "s|.*/||")
#echo $ORG

cd $PORG

STATSDIR=$(echo $(pwd)/stats)
if [[ -d $STATSDIR ]]; then
    rm -r $STATSDIR
fi
mkdir $STATSDIR

function deletefile() {
    if [[ -f $1 ]]; then
        rm $1
    fi
}

function find_artifacts() {
    #echo -- $1 $2 $3
    if [[ -d $1 ]]; then
        artifact_type=$(echo $1 | sed -e "s|.*/||")
        if [ -z "$SERVER" ]; then
            echo "num of $artifact_type: " $(ls $1 | wc -l)
        else
            echo "num of $artifact_type: " $(ls $1 | wc -l) : $(get_stats_from_server.sh $SERVER $ORG $USERNAME $PASSWORD $REALM $1 $2 $3)
        fi
    fi
}

function find_draft_artifacts() {

    draft_products=($(grep -l "type: draft_product" drafts/*))
    echo "num of draft products: ${#draft_products[@]}"

    for i in "${draft_products[@]}"; do
        # remove "meta.yml" from the filename and save name-ver
        # drafts/zoom-product-1.0.0.meta.yml -> zoom-product-1.0.0
        echo $(basename $i) | sed "s/.meta.yml//" >>$STATSDIR/draft_prods.txt
        # grep name: $i | sed -e s/".* "// >>$STATSDIR/draft_prods.txt
    done

    emptyprods=($(grep -l "apis: {}" drafts/*))
    echo "num of empty draft prods (e.g. contains only oauth APIs): ${#emptyprods[@]}"

    draft_prods_v2018=$([ -z "$TOPOLOGY_FILE_IN" ] && echo 0 || cat $TOPOLOGY_FILE | jq --arg ORG "$ORG" '.orgs.results[] | select(.name == $ORG) | .counts.draft_products')

    echo "num of net draft products:  $((${#draft_products[@]} - ${#emptyprods[@]})) "$([ -z "$TOPOLOGY_FILE_IN" ] && echo || echo ": $draft_prods_v2018")
    #echo "num of net draft products:  $(($products - $emptyprods))" : $(find_artifacts "draft-products" "list-all")

    #echo ${emptyprods[*]}
    for i in "${emptyprods[@]}"; do
        # remove ".yml" from the filename and save name-ver
        # drafts/dummy-1.0.0.yml -> dummy-1.0.0
        echo $(basename $i) | sed "s/.yml//" >>$STATSDIR/draft_prods_empty.txt
        # grep name: $i | sed -e s/".* "// >>$STATSDIR/draft_prods_empty.txt
    done

    draft_apis=($(ls drafts/*api.yml))

    draft_apis_v2018=$([ -z "$TOPOLOGY_FILE_IN" ] && echo 0 || cat $TOPOLOGY_FILE | jq --arg ORG "$ORG" '.orgs.results[] | select(.name == $ORG) | .counts.draft_apis')
    echo "num of draft APIs: ${#draft_apis[@]} "$([ -z "$TOPOLOGY_FILE_IN" ] && echo || echo ": $draft_apis_v2018")
    #echo "num of draft APIs: " $(ls drafts/*api.yml | wc -l) : $(find_artifacts "draft-apis" "list-all")

    for i in "${draft_apis[@]}"; do
        # remove "api.yml" from the filename and save name-ver
        # drafts/api-axe-ust-nam-1.0.api.yml -> api-axe-ust-nam-1.0
        echo $(basename $i) | sed "s/.api.yml//" >>$STATSDIR/draft_apis.txt
        #grep x-ibm-name: $i | cut -d " " -f2 >> $STATSDIR/draf|t_apis_org.txt
    done
}

function find_catalog_prods_apis() {
    array=($(echo "$1" | tr '/' '\n'))

    #filesufix=$(echo $1 | sed -e "s|.*/||g")
    if ((${#array[@]} == 4)); then
        # in spaces
        filesufix=${array[1]}_${array[3]}
    else
        # in catalog with no spaces
        filesufix=${array[1]}
    fi

    products=($(grep -l "type: product" $1/products/*.meta.yml))
    echo "num of products:  ${#products[@]}"

    for j in "${products[@]}"; do
        echo $(basename $j) | sed "s/.meta.yml//" >>$STATSDIR/prods_$filesufix.txt
    done

    emptyprods=($(grep -l "apis: {}" $1/products/*.yml))
    echo "num of empty products (e.g. contains only oauth APIs): ${#emptyprods[@]}"

    if ((${#array[@]} == 4)); then
        # in spaces
        prodsv2018=$([ -z "$TOPOLOGY_FILE_IN" ] && echo 0 || cat $TOPOLOGY_FILE | jq --arg ORG "$ORG" --arg CAT "$catalogname" --arg SPACE "${array[3]}" '.orgs.results[] | select(.name == $ORG) | .catalogs.results[] | select(.name == $CAT) | .spaces.results[] | select(.name == $SPACE) | .counts.products ')
    else
        # in catalog with no spaces
        prodsv2018=$([ -z "$TOPOLOGY_FILE_IN" ] && echo 0 || cat $TOPOLOGY_FILE | jq --arg ORG "$ORG" --arg CAT "$catalogname" '.orgs.results[] | select(.name == $ORG) | .catalogs.results[] | select(.name == $CAT) | .counts.products ')
    fi

    echo "num of net products:  $((${#products[@]} - ${#emptyprods[@]})) "$([ -z "$TOPOLOGY_FILE_IN" ] && echo || echo ": $prodsv2018")
    #echo "num of net products: $(($products - $emptyprods))" : $(find_artifacts "$1/products" "list-all")

    for j in "${emptyprods[@]}"; do
        echo $(basename $j) | sed "s/.meta.yml//" >>$STATSDIR/prods_empty_$filesufix.txt
        #grep name: $j | cut -d " " -f2 >> $STATSDIR/draft_prods_empy_$filesufix.txt
    done

    if ((${#array[@]} == 4)); then
        # in spaces
        apisv2018=$([ -z "$TOPOLOGY_FILE_IN" ] && echo 0 || cat $TOPOLOGY_FILE | jq --arg ORG "$ORG" --arg CAT "$catalogname" --arg SPACE "${array[3]}" '.orgs.results[] | select(.name == $ORG) | .catalogs.results[] | select(.name == $CAT) | .spaces.results[] | select(.name == $SPACE) | .counts.apis ')
    else
        # in catalog with no spaces
        apisv2018=$([ -z "$TOPOLOGY_FILE_IN" ] && echo 0 || cat $TOPOLOGY_FILE | jq --arg ORG "$ORG" --arg CAT "$catalogname" '.orgs.results[] | select(.name == $ORG) | .catalogs.results[] | select(.name == $CAT) | .counts.apis ')
    fi

    apis=($(grep -l "type: api" $1/products/*meta.yml))
    echo "num of APIs:  ${#apis[@]} "$([ -z "$TOPOLOGY_FILE_IN" ] && echo || echo ": $apisv2018")
    #um of APIs: " $(grep -l "type: api" $1/products/*meta.yml | wc -l) : $(find_artifacts "$1/apis" "list-all")

    for j in "${apis[@]}"; do
        # remove "api.meta.yml" from the filename and save name-ver
        # drafts/taglisting-1.0.api.meta.yml -> taglisting-1.0
        echo $(basename $j) | sed "s/.api.meta.yml//" >>$STATSDIR/apis_$filesufix.txt
        #grep x-ibm-name: $j | cut -d " " -f2 >> $STATSDIR/draft_apis_$filesufix.txt
    done
}

echo
echo "***************************************************************************"
echo Artifacts in pOrg: $ORG
echo "***************************************************************************"

#draft
if [[ -d drafts ]]; then
    find_draft_artifacts
fi

#echo "num of OAuth Providers: " `ls oauth-providers | wc -l`
find_artifacts "oauth-providers" "list"

#echo "num of tls-client-profiles: " `ls tls-client-profiles | wc -l`
find_artifacts "tls-client-profiles" "list-all"

#echo "num of user-registries: " `ls user-registries | wc -l`
find_artifacts "user-registries" "list"

find_artifacts "members" "list" "org"

# catalogs
#arr=($(ls catalogs))
#echo ${arr[*]}
#for i in "${arr[@]}"; do
for i in catalogs/*; do
    catalogname=$(echo $i | sed -e "s|catalogs/||")
    echo
    echo ===============================================================
    echo Artifacts in catalog: $catalogname
    echo ===============================================================

    if [[ -d "$i/products" ]]; then
        find_catalog_prods_apis "$i"
    fi

    if [[ -d $i/consumer-orgs ]]; then
        cd $i/consumer-orgs

        corgsv2018=$([ -z "$TOPOLOGY_FILE_IN" ] && echo 0 || cat $TOPOLOGY_FILE | jq --arg ORG "$ORG" --arg CAT "$catalogname" '.orgs.results[] | select(.name == $ORG) | .catalogs.results[] | select(.name == $CAT) | .counts.consumer_orgs')
        echo "num of consumer orgs: $(ls . | wc -l) "$([ -z "$TOPOLOGY_FILE_IN" ] && echo || echo ": $corgsv2018")
        #echo "num of consumer orgs: " $(ls . | wc -l) : $(find_artifacts "." "list" "no-scope")
        ls . >>$STATSDIR/corgs_$catalogname.txt

        appsv2018=$([ -z "$TOPOLOGY_FILE_IN" ] && echo 0 || cat $TOPOLOGY_FILE | jq --arg ORG "$ORG" --arg CAT "$catalogname" '.orgs.results[] | select(.name == $ORG) | .catalogs.results[] | select(.name == $CAT) | .counts.apps')
        appsv5=$(find . -name app.yml -print | wc -l)
        echo "num of applications: $appsv5 "$([ -z "$TOPOLOGY_FILE_IN" ] && echo || echo ": $appsv2018")
        #find . -name app.yml -print | sed -e s/".*apps\/"// | sed -e s/"\/app.yml"// >>$STATSDIR/apps_$i.txt
        find . -name app.yml -print | sed -e s/"\/app.yml"// >>$STATSDIR/apps_$catalogname.txt

        subsv2018=$([ -z "$TOPOLOGY_FILE_IN" ] && echo 0 || cat $TOPOLOGY_FILE | jq --arg ORG "$ORG" --arg CAT "$catalogname" '.orgs.results[] | select(.name == $ORG) | .catalogs.results[] | select(.name == $CAT) | .counts.subscriptions')
        subsv5=$(find . -name \*subscr-app*.yml -print | wc -l)
        echo "num of subscriptions: $subsv5 "$([ -z "$TOPOLOGY_FILE_IN" ] && echo || echo ": $subsv2018")
        #find . -name \*subscr-app*.yml -print | sed -e s/".*subscriptions\/"// | sed -e s/".yml"// >>$STATSDIR/subs_$i.txt
        find . -name \*subscr-app*.yml -print | sed -e s/".yml"// >>$STATSDIR/subs_$catalogname.txt

        cd ../../..
    fi

    #echo "num of configured oauth providers: " `ls $i/configured-oauth-providers | wc -l`
    find_artifacts $i/configured-oauth-providers "list"
    #echo "num of configured TLS client profiles: " `ls $i/configured-tls-client-profiles | wc -l`
    find_artifacts $i/configured-tls-client-profiles "list-all"
    #echo "num of configured user registries: " `ls $i/configured-catalog-user-registries | wc -l`
    find_artifacts $i/configured-catalog-user-registries "list" "no-scope"

    find_artifacts $i/members "list" "org"

    #################################################
    # Handle spaces
    #################################################
    if [[ -d "$i/spaces" ]]; then
        # spaces
        #arr_spaces=($(ls $i/spaces))
        #echo ${arr[*]}
        #for k in "${arr_spaces[@]}"; do
        for k in $i/spaces/*; do
            array=($(echo "$k" | tr '/' '\n'))
            echo
            echo ------------------------------------------
            echo "Artifacts in space: ${array[-1]}"
            echo ------------------------------------------
            if [[ -d "$k/products" ]]; then
                find_catalog_prods_apis "$k"
            fi

            find_artifacts $k/configured-oauth-providers "list"
            find_artifacts $k/configured-tls-client-profiles "list-all"
            #find_artifacts $k/configured-catalog-user-registries
            find_artifacts $k/members "list" "org"
        done
    fi
done
