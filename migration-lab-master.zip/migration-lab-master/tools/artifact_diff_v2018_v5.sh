#!/bin/bash
# For horizontal comparison of artifacts between v5 and v2018 (before and after migrations)
# usage: cmd v2018_artifact_dir v5_artifact_dir | tee <diff_result_file>
#   - v5_artifact_dir contains yaml artifacts cloned using apic immediately after dbextract snapshot for migration
#   - v2018_artifact_dir contains yaml artifacts cloned using apic immediately after the migration
#
# You need the helper utilites:
#   1. jq - JSON processor. Install: sudo apt-get install jq
#   2. yq 3.x (yq 2.x is not supported) -YAML processor. Install: sudo snap install yq
#   3. jd - JSON diff https://github.com/josephburnett/jd/releases/download/v1.1/jd
#   4. apicm - APIc Migration Utility (AMU v2018.4.1.10R2+) for sluggification 
# 
#Config files:
#   1. filter_file (jq_filter.txt): specify elements whose differences are inconsequential, e.g.
#       - only appears in v2018
#       - only appears in v5
#       - differences are insignificant
#   2. mapping_file (diff_mapping.txt): specify the element mapping from v2018 to v5, e.g.
#       - name changes due to sluggification in v2018
#       - format changes in v2018
# Outputs: 
#   Artifact name & version changes are saved in sluggified_names_file (sluggified_names.txt)
# mkz@us.ibm.com
# version: 2.0  4/14/2020

v2018_artifact_dir=$1
v5_artifact_dir=$2

sluggified_names_file=sluggified_names.txt

# cleanup
if [[ -f $sluggified_names_file ]]; then
    rm $sluggified_names_file
fi
#rm $v5_artifact_dir/*.yaml.json
#rm $v2018_artifact_dir/*.yaml.json

# define elements to be skipped in v2018
FILTER_FILE=jq_filter.txt
v2018_MAP_FILE=diff_mapping.txt

# read the filters in array. ignore comments starting with #
arr=($(grep -v "^#" $FILTER_FILE))

echo "************************************************************"
echo the following elements are ignored
echo "************************************************************"
for i in ${arr[*]}; do
    echo $i
done

# create jq filters for the ignored elements
num=${#arr[*]}
jq_expr="jq '"
for ((i = 0; i < num; i++)); do
    #ignore comments which starts with #
    if [[ "${arr[i]}" = \#* ]]; then
        continue
    fi
    #remove from jq
    jq_expr+="del(.${arr[i]}) | "
done
# replace last " | " with '
jq_expr=$(echo $jq_expr | rev | sed -e "s/|/'/" | rev)
#echo $jq_expr

# read the diff mapping in array
arr=($(grep -v "^#" $v2018_MAP_FILE))

echo "************************************************************"
echo the following elements are mapped from v2018 to v5
echo "************************************************************"
for i in ${arr[*]}; do
    echo $i
done

# create mapping cmds
num=${#arr[*]}
#map_cmd="sed -e "
for ((i = 0; i < num; i++)); do
    #ignore comments which starts with #
    if [[ "${arr[i]}" = \#* ]]; then
        continue
    fi
    #replace
    map_cmd+="sed -e 's|${arr[i]}|' | "
done
#remove the last "| "
map_cmd=$(echo $map_cmd | rev | sed -e "s/|//" | rev)
echo $map_cmd

function compare() {
    # if file exists, proceed to compare
    #if [ -f $2 ]; then
    echo
    echo "------------------------------------------------------------"
    echo "$1 :: $2"
    echo "------------------------------------------------------------"
    eval "yq r -j -P $1 | $map_cmd | $jq_expr >$1.json"
    eval "yq r -j -P $2 | $jq_expr | jd $1.json"
}

echo
echo "************************************************************"
echo files in v2018 or v5 ONLY
echo "************************************************************"
diff -q $v2018_artifact_dir $v5_artifact_dir | grep Only | sort

# read all files in v5_artifact_dir
v5_files=$v5_artifact_dir/*.yaml
for v5file in $v5_files; do

    # remove "_product_" which is contained in cloned v5 product files while it is not in v2018
    normalized_name=$(echo $v5file | sed -e "s|.*/||" | sed -e "s|product_||")
    #echo $normalized_name

    # format: productname_versionname.yaml
    versionname=$(echo $normalized_name | sed -e "s|.*_||" | sed -e "s|.yaml||")
    productname=$(echo $normalized_name | sed -e "s|_$versionname.yaml||")

    #sluggify the names
    sluggifiedproductname=$(apicm sluggify $productname)
    sluggifiedversionname=$(apicm sluggify -v $versionname)

    # if [[ $versionname =~ ^[0-9]+\.[0-9]+\.[0-9] || $versionname =~ ^[0-9]+\.[0-9] || $versionname =~ ^[0-9] ]]; then
    #     #echo -- version num: $versionname
    #     # 1.0.0, 1.0, 1, no need to sluggify
    #     sluggifiedversionname=$versionname
    # else
    #     sluggifiedversionname=$(apicm sluggify $versionname)
    # fi

    v2018filename=${sluggifiedproductname}_${sluggifiedversionname}.yaml

    # if sluggified name differs from v5, print here
    if [[ "$normalized_name" != "$v2018filename" ]]; then
        echo $normalized_name : $v2018filename >>$sluggified_names_file
    fi

    v2018file=$v2018_artifact_dir/$v2018filename
    #echo $v2018filename $v5filename

    if [ -f $v2018file ]; then
        compare $v2018file $v5file
    fi
done

# cleanup
rm $1/*.yaml.json
