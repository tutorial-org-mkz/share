#!/bin/bash
# For vertical comparison of artifacts that evolved over time in v5 or v2018 or future versions.
# usage: cmd artifact_dir_1 artifact_dir_2 | tee <diff_result_file>
#   - The artifact_dir_2 contains yaml artifacts cloned using apic immediately after dbextract snapshot for migration
#   - artifact_dir_1 contains yaml artifacts cloned using apic immediately after the migration
# You need utilites:
#   1. jq - JSON processor. Install: sudo apt-get install jq
#   2. yq 3.x (yq 2.x is not supported) -YAML processor. Install: sudo snap install yq
#   3. jd - JSON diff https://github.com/josephburnett/jd/releases/download/v1.1/jd
# 
# Config file:
#  filter: specify all ignored elements in jq_filter.txt
#   For elements that are inconsequential but -
#       - only appears in v2018
#       - only appears in v5
#       - differ insignificantly
# mkz@us.ibm.com
# version: 2.0  4/14/2020

artifact_dir_1=$1
artifact_dir_2=$2

# define elements to be skipped in v2018
FILTER_FILE=jq_filter.txt

# read the filters in array
arr=($(cat $FILTER_FILE))

echo "************************************************************"
echo the following elements are ignored
echo "************************************************************"
for i in ${arr[*]}; do
    echo $i
done

# create jq filters for the ignored elements
num=${#arr[*]}
jq_expr="jq '"
for ((i = 0; i < num; i++)); do
    #ignore comments which starts with #
    if [[ "${arr[i]}" = \#* ]]; then
        continue
    fi
    #remove from jq
    jq_expr+="del(.${arr[i]}) | "
done
# replace last " | " with '
jq_expr=$(echo $jq_expr | rev | sed -e "s/|/'/" | rev)
#echo $jq_expr

function compare() {
    # if file exists, proceed to compare
    #if [ -f $2 ]; then
    echo
    echo "------------------------------------------------------------"
    echo "$1 :: $2"
    echo "------------------------------------------------------------"
    eval "yq r -j -P $1 | $jq_expr > $1.json"
    eval "yq r -j -P $2 | $jq_expr | jd $1.json"
}

echo
echo "************************************************************"
echo files in $artifact_dir_1 or $artifact_dir_2 ONLY
echo "************************************************************"
diff -q $artifact_dir_1 $artifact_dir_2 | grep Only | sort

# read all files in artifact_dir_1
artifacts_1=$artifact_dir_1/*.yaml
for f in $artifacts_1; do
    filename=$(echo $f | sed -e "s|.*/||")
    artifacts_2=$artifact_dir_2/$filename
    #echo $f $artifacts_2
    if [ -f $artifacts_2 ]; then
        compare $f $artifacts_2
    fi
done

# cleanup
rm $1/*.yaml.json
