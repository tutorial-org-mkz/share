#!/bin/bash
 # version: 2.2 08/24/2020
# mkz@us.ibm.com
#
# Pay attention to the script input section.
# need yaml_massager.sh and apicm to be in the search PATH

# add current dir to search path
export PATH=$PATH:.

# redirect stdout/stderr to log file in the current dir
exec > >(tee -i ${0##*/}.log)
exec 2>&1

#####################################################
# script inputs
# the mapping files are optional [OAUTH_MAPPING, GW_MAPPING_FILE, SPECIFIC, GLOBAL]
# replace [your - porg] with the pOrg name to be mapped
#####################################################
OAUTH_MAPPING=OAuth-Providers-[your-porg].csv
GW_MAPPING_FILE=gw_mapping.yml
SPECIFIC=specific-[your-porg].csv ### use global.csv if jq or yaml2json utils cannot be installed
GLOBAL=global-[your-porg].csv
CLOUDDIR=cloud ### due to AMU restriction, CLOUDDIR has to be named "cloud" for now.
PORG=$CLOUDDIR/provider-orgs/[your-porg]
CLOUDDIR_BAK=$CLOUDDIR.bak

echo '******************************************************'
echo Input Parameters
echo -- pOrg: $PORG
echo -- Gateway mapping file: $GW_MAPPING_FILE
echo -- OAuth mapping file: $OAUTH_MAPPING
echo -- Specific.csv for yaml_massager: $SPECIFIC
echo -- Global.csv for yaml_massager: $GLOBAL
echo -- Cloud directory: $CLOUDDIR
echo -- Cloud backup directory: $CLOUDDIR_BAK
echo '******************************************************'
# Pre-processing the artifacts ...
echo Pre-processing the artifacts ...
# echo -- Removing the internal catalog for markets
# if [ -d $PORG/catalogs/internal ]; then
#   rm -r $PORG/catalogs/internal
# fi
echo -- Creating a backup for $CLOUDDIR at $CLOUDDIR.bak
if [ -d $CLOUDDIR.bak ]; then
  rm -r $CLOUDDIR.bak
fi
cp -r $CLOUDDIR $CLOUDDIR.bak
echo '******************************************************'

echo ------------------------------------------------------
echo copy gw mapping file to gw dirs
echo ------------------------------------------------------
GW_DIR=$CLOUDDIR/admin-org/availability-zones/availability-zone-default/gateway-services

if [ -f $GW_MAPPING_FILE ]; then
  for d in $GW_DIR/*; do
    echo ---- copying $GW_MAPPING_FILE to $d/mapping.yml
    cp $GW_MAPPING_FILE "$d/mapping.yml"
  done
fi

echo ------------------------------------------------------
echo run yaml_massager.sh -s $SPECIFIC -g $GLOBAL -d $PORG
echo ------------------------------------------------------
# if both inputs are null, do nothing
if [[ ! -z $SPECIFIC ]] && [[ ! -z $GLOBAL ]]; then
  yaml_massager.sh -s $SPECIFIC -g $GLOBAL -d $PORG
elif [[ -z $SPECIFIC ]] && [[ ! -z $GLOBAL ]]; then
  yaml_massager.sh -g $GLOBAL -d $PORG
elif [[ ! -z $SPECIFIC ]] && [[ -z $GLOBAL ]]; then
  yaml_massager.sh -s $SPECIFIC -d $PORG
fi

if [[ ! -z $OAUTH_MAPPING ]]; then
  echo ------------------------------------------------------
  echo set OAuth Providers for APIs
  echo ------------------------------------------------------
  # clean the special char when saved from vscode <U+FEFF> which bombs Mac terminal
  # remove comments
  CLEANED_MAPPINGFILE=cleaned-$OAUTH_MAPPING
  awk '{ if (NR==1) sub(/^\xef\xbb\xbf/,""); print }' $OAUTH_MAPPING | grep -v "^#" >$CLEANED_MAPPINGFILE

  # get all filenames
  # filenames=($(grep -E '[[:upper:]]+' $CLEANED_MAPPINGFILE | sed s/:.*//))
  filenames=($(cat $CLEANED_MAPPINGFILE | sed s/:.*//))
  # sluggify the file names
  for f in "${filenames[@]}"; do
    sluggified_name=$(apicm sluggify $f)
    if [[ "$f" != "$sluggified_name" ]]; then
      echo ---- sluggify the API file name from $f to $sluggified_name
      sed -i "s/$f:/$sluggified_name:/" $CLEANED_MAPPINGFILE
    fi
  done

  apis=($(cut -d ',' -f1 $CLEANED_MAPPINGFILE))
  providers=($(cut -d ',' -f2 $CLEANED_MAPPINGFILE))
  tokenURLs=($(cut -d ',' -f3 $CLEANED_MAPPINGFILE))
  #authorizationUrls=($(cut -d ',' -f4 $CLEANED_MAPPINGFILE))
  #printf "%s\n" "${apis[0]}.api.yml  " "${providers[0]}  " "${tokenURLs[0]}"

  # get number of the apis
  tLen=${#apis[@]}

  # replace oauth settings in all files
  for ((i = 0; i < ${tLen}; i++)); do
    apiFile=${apis[$i]//:/-}.api.yml
    #apiFile=${apiFile//:/-}
    provider=${providers[$i]}
    tokenUrl=${tokenURLs[$i]}
    #authorizationUrl=${authorizationUrls[$i]}
    echo $i -- $apiFile $provider $tokenUrl

    ## find files in drafts, catalog, spaces
    apiFiles=($(find $PORG -name $apiFile))

    if [ ${#apiFiles[@]} -eq 0 ]; then
      echo "ERROR ==> $apiFile is NOT found!"
      continue
    fi

    # deal with drafts vs catalogs vs spaces separately
    for f in "${apiFiles[@]}"; do
      echo ---- replacing oauth-provider with $provider.yml in $f

      # drafts : drafts/xxx.api.yml
      if [[ "$f" == *"/drafts/"* ]]; then
        sed -i -e "s|x-ibm-oauth-provider:.*|x-ibm-oauth-provider: 'name://../oauth-providers/$provider.yml'|" $f
      fi

      # catalogs: catalogs/cat1/products/xxx.api.yml
      if [[ "$f" == *"/catalogs/"* ]]; then
        sed -i -e "s|x-ibm-oauth-provider:.*|x-ibm-oauth-provider: 'name://../../../oauth-providers/$provider.yml'|" $f
      fi

      # spaces: catalogs/cat1/spaces/space1/products/xxx.api.yml
      if [[ "$f" == *"/spaces/"* ]]; then
        sed -i -e "s|x-ibm-oauth-provider:.*|x-ibm-oauth-provider: 'name://../../../../../oauth-providers/$provider.yml'|" $f
      fi

    done

    if [ -n "$tokenUrl" ]; then
      echo ---- replace tokenUrl with $tokenUrl
      sed -i -e "s|tokenUrl:.*|tokenUrl: $tokenUrl|" ${apiFiles[*]}
    fi

    # if [ -n "$authorizationUrl" ]; then
    #   echo ---- replace authorizationUrl with $authorizationUrl
    #   sed -i -e "s|authorizationUrl:.*|authorizationUrl: $authorizationUrl|" ${apiFiles[*]}
    # fi
  done

  # cleanup
  if [ ! -z "$CLEANED_MAPPINGFILE" ]; then
    rm $CLEANED_MAPPINGFILE
  fi
fi

# Post-processing the artifacts ...
echo '******************************************************'
echo Post-processing the artifacts ...
echo -- All console outputs are save in ${0##*/}.log
# Error Checking
errors=($(grep -i 'ERROR\|snap-confine\|No such file\|not found' ${0##*/}.log))
if [ ${#errors[@]} -eq 0 ]; then
  echo "-- No errors, hooray"
else
  # printf '%s\n' "${errors[@]}"
  grep -i 'ERROR\|snap-confine\|No such file\|not found' ${0##*/}.log >${0##*/}.err
  echo "-- Errors found! Please fix the ERRORs in ${0##*/}.err before proceeding."
fi

echo '******************************************************'
diff -rq $CLOUDDIR $CLOUDDIR.bak >artifacts_diff_resulted_from_${0##*/}.txt
echo -- $(cat artifacts_diff_resulted_from_${0##*/}.txt | wc -l) artifacts have been modified.
echo -- The details of the differences resulted from this script are saved in artifacts_diff_resulted_from_${0##*/}.txt
echo '******************************************************'
