#!/bin/bash -v
# v1 7/27/2020
# mkz@us.ibm.com

# grep -r --include="*api.yml" "cmc-\|dod-" * | grep "value:\|jws\|jwt"
# cmp-create-userprovorg-2.0.0.api.yml:      value: cmc-sso-dev-profile
# account-and-transaction-api-specification-v3.1.0.api.yml:      value: cmc-citigroupsoa-dsig-0
# payment-initiation-api-specification-v3.1.0.api.yml:      value: cmc-citigroupsoa-dsig-0
# apim-baseurl-cmp-2.0.0.api.yml:      value: cmc-sso-dev-profile
# cmp-lookup-consumer-onboarding-2.0.0.api.yml:      value: cmc-sso-dev-profile
# cmp-create-consumer-org-2.0.0.api.yml:      value: cmc-sso-dev-profile
# jwt-api-200.api.yml:              jws-crypto: cmc-icg-markets-ic-0
# jwt-api-200.api.yml:              jws-crypto: cmc-icg-markets-ic-1

# grep -r --include="*api.yml" "cmc-\|dod-" * | grep "value:\|jws\|jwt" | sed "s|.*/||"
# grep -r --include="*api.yml" "cmc-\|dod-" * | grep "value:\|jws\|jwt" | sed "s|.*/||" | sort -u
# jwt-api-1.0.0.api.yml:              jws-crypto: cmc-icg-markets-ic-0
# jwt-api-1.0.0.api.yml:              jws-crypto: cmc-icg-markets-ic-1
# jwt-api-200.api.yml:              jws-crypto: cmc-icg-markets-ic-0
# jwt-api-200.api.yml:              jws-crypto: cmc-icg-markets-ic-1
# payment-initiation-api-specification-v3.1.0.api.yml:      value: cmc-citigroupsoa-dsig-0
# product-operations-1.0.0.api.yml:      value: cmc-sso-dev-profile
# product-operations-1.0.1.api.yml:      value: cmc-sso-dev-profile
# product-subscription-api-1.0.0.api.yml:      value: cmc-sso-dev-profile
# product-subscription-api-1.0.1.api.yml:      value: cmc-sso-dev-profile
# product-subscription-api-2.0.0.api.yml:      value: cmc-sso-dev-profile
# product-subscription-api-3.0.0.api.yml:      value: cmc-sso-dev-profile
# product-subscription-api-old-1.0.0.api.yml:      value: cmc-sso-dev-profile
# product-subscription-approval-api-1.0.1.api.yml:      value: cmc-sso-dev-profile
# provider-organization-api-1.0.0.api.yml:      value: cmc-sso-dev-profile
# provider-organization-api-producti-list-1.0.0.api.yml:      value: cmc-icg-markets-ic
# provider-organization-api-producti-list-2.0.0.api.yml:      value: cmc-icg-markets-ic
# subscription-product-app-1.0.0.api.yml:      value: cmc-sso-dev-profile
# test-wrapper-cmp-create-consumer-org-1.0.0.api.yml:      value: cmc-sso-dev-profile

# grep -r --include="*api.yml" "cmc-\|dod-" * | grep "value:\|jws\|jwt" | sed "s|.*/||" | sort -u | sed "s/:.*.: /,/"
# jwt-api-1.0.0.api.yml,cmc-icg-markets-ic-0
# jwt-api-1.0.0.api.yml,cmc-icg-markets-ic-1
# subscription-product-app-1.0.0.api.yml,cmc-sso-dev-profile
# test-wrapper-cmp-create-consumer-org-1.0.0.api.yml,cmc-sso-dev-profile
# unsubscribe-product-1.0.0.api.yml,cmc-sso-dev-profile

# grep -r --include="*api.yml" "cmc-\|dod-" * | grep "value:\|jws\|jwt" | sed "s|.*/||" | sort -u | sed "s/:.*.: /,/" | sed "s/.*,//" | sort -u
# cmc-citigroupsoa-dsig-0
# cmc-icg-markets-ic
# cmc-icg-markets-ic-0
# cmc-icg-markets-ic-1
# cmc-sso-dev-profile

PORG_DIR=$1
PORG_NAME=$(basename $PORG_DIR)

REPLACEMENT_FILE=global_tls.csv
if [[ -f $REPLACEMENT_FILE ]]; then
    # remove the old one
    rm $REPLACEMENT_FILE
fi

#find cloud/provider-orgs/gw -name \*api.yml | xargs grep "cmc-\|dod-" | grep "value:\|jws\|jwt" | sed "s|.*/||" | sort -u | sed "s/:.*.: /,/"
instances=$(find $PORG_DIR -name \*api.yml | xargs grep "cmc-\|dod-" | grep "value:\|jws\|jwt" | sed "s|.*/||" | sort -u | sed "s/:.*.: /,/")

for instance in ${instances[@]}; do
    # instance: jwt-api-1.0.0.api.yml,cmc-icg-markets-ic-0 => cmc-icg-markets-ic-0
    tls=$(echo $instance | sed "s/.*,//")

    # get first and last part of cmc-icg-markets-ic-0
    last_part=$(echo $tls | sed "s/.*-//")
    first_part=$(echo $tls | sed "s/-.*//")

    # test if it is a num
    re='^[0-9]+$'
    if [[ $last_part =~ $re ]]; then
        # cmc-icg-markets-ic-0 => $PORG_NAME-icg-markets-icV1.0.0-0
        replacement=$(echo $tls | sed "s/$first_part/$PORG_NAME/" | sed "s/-$last_part/V1.0.0-$last_part/")
    else
        # cmc-icg-markets-ic => $PORG_NAME-icg-markets-icV1.0.0
        replacement=$(echo $tls | sed "s/$first_part/$PORG_NAME/")V1.0.0
    fi

    # append replacement to instance and append instance to $REPLACEMENT_FILE
    echo ${instance},${replacement} >> $REPLACEMENT_FILE

done
