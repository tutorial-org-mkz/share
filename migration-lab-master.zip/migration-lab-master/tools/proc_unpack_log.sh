#!/bin/bash

# catagorize the errors in unpack log.
#
# Input: the unpack log file in the AMU logs dir.

# $1: the unpack log file name without extension .log
LOGFILE=$1
if [[ ! -f $LOGFILE ]]; then
    echo "log file $LOGFILE is not found or given."
    echo "usage: proc_unpack_log.sh unpack_log_file_name"
    exit 1
fi
LOG_FILE=$(echo $LOGFILE | sed s/.log//)

echo "-- extracting oauth related issues in ${LOG_FILE}_oauth.log ... "
grep -i oauth $LOG_FILE.log >${LOG_FILE}_oauth.log
grep -iv oauth $LOG_FILE.log >${LOG_FILE}_1.log

echo "-- extracting PENDING artifacts related issues in ${LOG_FILE}_pending.log ... "
cat ${LOG_FILE}_1.log | grep -i pending >${LOG_FILE}_pending.log

echo "-- all other issues are saved in ${LOG_FILE}_2.log ... "
cat ${LOG_FILE}_1.log | grep -vi pending >${LOG_FILE}_2.log

echo "-- catagorizing oauth related issues in oauth_*.log ... "
# matching this pattern " Multiple OAuth Providers matching basePath: (/cv/api) and scopes: (/api were found for draft API api-bwics:1.0)"
grep -A 1  -P "(?=Multiple OAuth Providers matching basePath:).*(?= and scopes:)" ${LOG_FILE}_oauth.log | sed 's/ *$//g' > oauth_ambiguity.log

grep " Multiple OAuth Providers" oauth_ambiguity.log | sed "s/.*API //" > oauth_ambiguity_apis_all.log
grep "OAuth Providers match this basePath and scopes:" oauth_ambiguity.log | sed "s/.*scopes: //" > oauth_ambiguity_providers_all.log

# join the apis and providers and remove the duplicates
paste -d'|' oauth_ambiguity_apis_all.log oauth_ambiguity_providers_all.log | sort -u |sort -k2 -t '|' > oauth_ambiguity_apis_providers.log

sort -u oauth_ambiguity_providers_all.log > oauth_ambiguity_providers_unique.log
sort -u oauth_ambiguity_apis_all.log > oauth_ambiguity_apis_unique.log

cat oauth_ambiguity.log | grep -oP '(?<=draft API )[^ ]*'  | sort -u > oauth_ambiguity_draft_apis.log
cat oauth_ambiguity.log | grep -oP '(?<=for API )[^ ]*'  | sort -u > oauth_ambiguity_catalog_apis.log
cat ${LOG_FILE}_oauth.log | grep -oP '(?<=placeholder OAuth Provider which must be replaced in API )[^ ]*' | sed 's/.$//' | sort -u > oauth_placeholder_apis.log


comm -12 <(sort oauth_ambiguity_catalog_apis.log) <(sort oauth_ambiguity_draft_apis.log) >oauth_ambiguity_in_both_draft_catalog_oauth.log
grep -v -f oauth_ambiguity_in_both_draft_catalog_oauth.log oauth_ambiguity_draft_apis.log >oauth_ambiguity_only_in_draft_apis.log
grep -v -f oauth_ambiguity_in_both_draft_catalog_oauth.log oauth_ambiguity_catalog_apis.log >oauth_ambiguity_only_in_catalog_apis.log
