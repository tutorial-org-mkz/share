#!/bin/bash
#
# create a list of name changes due to sluggification
#
# Usage: cmd catalog_dir db_extract_dir

CATALOG=$1

DBEXTRACT=$2

CORG_DIR=$CATALOG/consumer-orgs
DBEXTRACT_ORG_DIR=$DBEXTRACT/orgs/docs
DBEXTRACT_APP_DIR=$DBEXTRACT/appregistrations/docs

# output files
CORG_DIFF=sluggified_corg_names.txt
APP_DIFF=sluggified_app_names.txt

if [[ -f $CORG_DIFF ]]; then
    rm $CORG_DIFF
fi
if [[ -f $APP_DIFF ]]; then
    rm $APP_DIFF
fi

# loop thru all cOrgs
echo "---- find and save the sluggified corg names to $CORG_DIFF ..."
for org in $CORG_DIR/*; do
    org_name=$(grep name $org/consumer-org.yml | sed "s/name: //")
    org_id=$(grep v5_id $org/consumer-org.yml | sed "s/.*v5_id: //")
    org_name_v5=$(grep name ${DBEXTRACT_ORG_DIR}/${org_id}.json | sed 's/"//g; s/,//; s/.*name: //')

    if [[ ! "$org_name" == "$org_name_v5" ]]; then
        echo $org_name : $org_name_v5 >> $CORG_DIFF
    fi
done

# find all apps and loog thru
echo "---- find and save the sluggified app names to $APP_DIFF ..."
apps=$(find $CORG_DIR -name app.yml)
# echo $apps
for app in ${apps[@]}; do
    # echo $app
    app_name=$(grep name $app | sed "s/name: //")
    #app_id=$(grep v5_id $app | sed "s/.*v5_id: //")
    # app title is the original v5 name
    app_title=$(grep title $app | sed "s/title: //")
    # app_name_v5=$(grep name ${DBEXTRACT_APP_DIR}/${app_id}.json | sed 's/"//g; s/,//; s/.*name: //')
    if [[ ! "$app_name" == "$app_title" ]]; then
        echo $app_name : $app_title >> $APP_DIFF
    fi
done
