#!/bin/bash
# v1.3
# mkz@us.ibm.com
# usage: getTopology2018.sh <cloud_mgr> <admin_id> <passwd> <realm>
# admin_id/pwd are credentials for the admin org (cmc).
# realm is the user registry for authenticating the user. Usually admin/default-idp-1
# The topology_stats.json file contains the artifacts stats of the entire platform.

SERVER=$1
USERNAME=$2
PASSWORD=$3

REALM=$4
#admin/default-idp-1

TOPOLOGY_FILE=topology_stats.json

CLIENT_ID=599b7aef-8841-4ee2-88a0-84d49c4d6ff2
CLIENT_SECRET=0ea28423-e73b-47d4-b40e-ddb45c48bb0c

# Get bearer token
#echo "--- Getting token ..."

TOKEN_RESPONSE=$(curl -k -s -X POST -d '{"username": "'$USERNAME'", "password": "'$PASSWORD'", "realm": "'$REALM'", "client_id": "'$CLIENT_ID'", "client_secret": "'$CLIENT_SECRET'", "grant_type": "password"}' -H 'Content-Type: application/json' -H 'Accept: application/json' https://$SERVER/api/token)
#echo $TOKEN_RESPONSE

TOKEN=$(grep access_token <<<"$TOKEN_RESPONSE" | sed -e s/.*:.// | sed -e s/[\"\|\,]//g)
#echo "Token =" $TOKEN

#echo "--- Getting Topology ... "
curl -ks --request GET \
    -H "Accept: application/json" \
    -H "Authorization: bearer $TOKEN" \
    https://$SERVER/api/cloud/topology
